package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="Assurance"                                
     , summary=""
     , relativeUrl=""
     , connection="GranteePortal"
     )             
public class Assurance {

	@PageWaitAfter.Timed(durationSeconds = 10)
	@LinkType()
	@FindBy(xpath = "//*[@id=\"Page:frm\"]//a[1]")
	public WebElement ViewAssurances;
	
	@PageWaitAfter.Timed(durationSeconds = 10)
	@LinkType()
	@FindBy(xpath = "//*[@id=\"Page:frm\"]//a[2]")
	public WebElement ViewCertifications ;

	@BooleanType()
	@FindBy(id = "Page:frm:chkbox")
	public WebElement chkbox;

	@TextType()
	@FindBy(id = "Page:frm:name")
	public WebElement name;

	@ButtonType()
	@FindByLabel(label = "Sign and Submit")
	public WebElement signAndSubmit;
			
}
