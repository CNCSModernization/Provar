package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ActionReport"                                
     , summary=""
     , relativeUrl=""
     , connection="POAdmin"
     )             
public class ActionReport {

	@TextType()
	@FindBy(xpath = "//span[@class=\"lookupInput\"]/a")
	public WebElement nOFOID;
	@LinkType()
	@FindBy(xpath = "//td[contains(text(),'NOFO ID')]/following-sibling::td[1]//a")
	public WebElement NOFO_Id;
			
}
