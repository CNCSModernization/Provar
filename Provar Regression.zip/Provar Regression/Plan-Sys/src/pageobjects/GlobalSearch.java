package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.provar.core.model.ui.api.UiFacet;
import com.provar.core.testapi.annotations.*;
import com.provar.plugins.forcedotcom.core.ui.pagecontrols.cke.CkEditor;

@Page( title="GlobalSearch"                                
     , summary=""
     , relativeUrl=""
     , connection="PO"
     )             
public class GlobalSearch {

	@TextType()
	@FindBy(id = "phSearchInput")
	public WebElement search;

	@PageRow()
	public static class Application {

		@LinkType()
		@FindBy(xpath = ".//th[contains(@class, \"dataCell\")]//a")
		public WebElement applicationID;
		@LinkType()
		@FindBy(linkText = "547925")
		public WebElement budgetNumber;
		@LinkType()
		@FindBy(xpath = "//*[@id=\"pg:j_id486_body\"]/table/tbody/tr[2]/th/a")
		public WebElement budgetNumber1;
		@LinkType()
		@FindBy(xpath = "//*[@id=\"pg:j_id551_body\"]/table/tbody/tr[2]/td[1]/a[1]")
		public WebElement action;
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//table[contains(@class, \"list\")]")
	@PageTable(firstRowContainsHeaders = true, row = Application.class)
	public List<Application> Application;

	@PageRow()
	public static class AwardTable {
	
		@LinkType()
		@FindBy(xpath = ".//th[contains(@class, \"dataCell\")]//a")
		public WebElement AwardId;
		@LinkType()
		@FindBy(xpath = "//*[@id=\"Award__c_body\"]/table/tbody/tr[2]/th/a")
		public WebElement awardID;
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//*[@id=\"Award__c_body\"]//table")
	@PageTable(firstRowContainsHeaders = true, row = AwardTable.class)
	public List<AwardTable> AwardTable;
	@TextType()
	@FindBy(xpath = "//*[@id=\"cke_j_id0:theForm:pgbtnid:j_id335:j_id341:j_id345:textAreaDelegate_Amendment_Justification__c\"]")
	public CkEditor textAreaDelegate_Amendment_Justification__c;
	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save;
	@ButtonType()
	@FindByLabel(label = "Final Save")
	public WebElement finalSave;
			
}
