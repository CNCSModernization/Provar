package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title=""                                
               , summary=""
               , page="NotificationofIntenttoApply"
               , namespacePrefix=""
               , object="NOFA__c"
               , connection="GranteePortal"
     )             
public class NotificationofIntenttoApply {

	@TextType()
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Authorized_Representative__c}\"]")
	public WebElement authorizedRepresentative;
	@TextType()
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Point_of_Contact__c}\"]")
	public WebElement pointOfContact;
	@ChoiceListType(values = { @ChoiceListValue(value = "Governor-Appointed State Commission"),
			@ChoiceListValue(value = "Public/private nonprofit organizations"),
			@ChoiceListValue(value = "Institution of higher education"),
			@ChoiceListValue(value = "Gov. entities within states/territories"),
			@ChoiceListValue(value = "Gov-recognized veteran service org."),
			@ChoiceListValue(value = "Labor organization"), @ChoiceListValue(value = "Partnerships and Consortia"),
			@ChoiceListValue(value = "Indian Tribe"), @ChoiceListValue(value = "Grantmaking institution"),
			@ChoiceListValue(value = "Eligible Partnership"), @ChoiceListValue(value = "Other (please specify)") })
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Describe_the_Application_Organization__c}\"]")
	public WebElement describeTheApplicationOrganization;
	@ChoiceListType(values = { @ChoiceListValue(value = "Disaster Services"),
			@ChoiceListValue(value = "Economic Opportunity"), @ChoiceListValue(value = "Education"),
			@ChoiceListValue(value = "Environmental Stewardship"), @ChoiceListValue(value = "Healthy Futures"),
			@ChoiceListValue(value = "Veterans and Military Families"), @ChoiceListValue(value = "Capacity Building"),
			@ChoiceListValue(value = "Youth Development") })
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Primary_Focus_Area__c}\"]")
	public WebElement primaryFocusArea;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!SaveAsDraft}']")
	public WebElement saveAndSubmit;
	@TextType()
	@VisualforceBy(componentXPath = "apex:outputPanel[not(@id)][2]/apex:pageBlockSection[2]/apex:pageBlockSection[3]//apex:inputField[@value = \"{!applicationInput.Point_of_Contact__c}\"]")
	public WebElement ContactPerson;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!showPopup}']")
	public WebElement saveAndSubmit1;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:outputPanel[@id='popInnerOutputPnl']/apex:commandButton[@action='{!SaveAsDraft}']")
	public WebElement saveAndSubmitPopUp;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!redirectToDetail}']")
	public WebElement done;
	
}
