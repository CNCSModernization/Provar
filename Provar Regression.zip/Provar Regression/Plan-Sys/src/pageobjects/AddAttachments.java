package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Add Attachments"                                
               , summary=""
               , page="AddAttachments"
               , namespacePrefix=""
               , object="Attachment__c"
               , connection="GranteePortal"
     )             
public class AddAttachments {

	@ButtonType(file = true)
	@FindBy(xpath = "//input[@type='file']")
	public WebElement file;
	@ChoiceListType(values = { @ChoiceListValue(value = "--None--"),
			@ChoiceListValue(value = "IRS Certification of Non-Profit Status"),
			@ChoiceListValue(value = "1199 Direct Deposit"), @ChoiceListValue(value = "Letters of Support"),
			@ChoiceListValue(value = "Evidence") })
	@FindBy(xpath = "//select")
	public WebElement Type;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@id='uploadBtn']")
	public WebElement AttachFiles;
	
}
