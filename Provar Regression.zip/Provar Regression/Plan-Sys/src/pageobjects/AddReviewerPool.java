package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Add Reviewer Pool"                                
               , summary=""
               , page="AddReviewerPool"
               , namespacePrefix=""
               , object=""
               , connection="OGPO"
     )             
public class AddReviewerPool {

	@PageWaitAfter.Timed(durationSeconds = 10)
	@TextType()
	@VisualforceBy(componentXPath = "apex:inputfield[@id='fName']")
	public WebElement firstName;

	@PageRow()
	public static class Reviewers {

		@BooleanType()
		@FindBy(xpath = ".//input[contains(@class, \"contactCb\")]")
		public WebElement SelectBox;
	}

	@FindBy(id = "page:form:pb:results:j_id59:tb")
	@PageTable(firstRowContainsHeaders = false, row = Reviewers.class)
	public List<Reviewers> Reviewers;
	@ButtonType()
	@FindByLabel(label = "Process Selected")
	public WebElement processSelected;
	
}
