package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title=""                                
               , summary=""
               , page="NotificationEditPage"
               , namespacePrefix=""
               , object="Application3__c"
               , connection="PO"
     )             
public class NotificationEditpage {

	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Identify_program_operating_site_s__c}\"]")
	@SalesforceField(name = "Identify_program_operating_site_s__c", object = "Application3__c")
	public WebElement identifyProgramOperatingSiteS;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!Save}']")
	public WebElement saveAndSubmit;
	
}
