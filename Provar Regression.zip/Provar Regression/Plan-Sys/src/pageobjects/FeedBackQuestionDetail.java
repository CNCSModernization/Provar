package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Feed Back Question Detail"                                
               , summary=""
               , page="FeedBackQuestionDetail"
               , namespacePrefix=""
               , object="Application_Feedback__c"
               , connection="OGPO"
     )             
public class FeedBackQuestionDetail {

	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!submit}']")
	public WebElement submit;
	
}
