package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.provar.core.model.ui.api.UiFacet;
import com.provar.core.testapi.annotations.*;

@Page(title = "BudgetApplication", summary = "", relativeUrl = "", connection = "GranteePortal")
public class BudgetApplication {

	@ChoiceListType(values = { @ChoiceListValue(value = "Program Grant Budget"),
			@ChoiceListValue(value = "VISTA Standard"), @ChoiceListValue(value = "Support Grant Budget"),
			@ChoiceListValue(value = "Standard Budget"), @ChoiceListValue(value = "Praveen"),
			@ChoiceListValue(value = "ACSN - Cost Reimbursement"),
			@ChoiceListValue(value = "Melissa's Sample Budget Form"), @ChoiceListValue(value = "VISTA"),
			@ChoiceListValue(value = "RSVP"), @ChoiceListValue(value = "MLK"), @ChoiceListValue(value = "SIF"),
			@ChoiceListValue(value = "FGP/SCP - Cost Reimbursement"),
			@ChoiceListValue(value = "FGP/SCP - Fixed Amount"), @ChoiceListValue(value = "Other"),
			@ChoiceListValue(value = "ACSN - Fixed Amount"), @ChoiceListValue(value = "er"),
			@ChoiceListValue(value = "Test Beta") })
	@FindBy(xpath = "//*[contains(@id,\"template_select\")]")
	public WebElement template_select;
	@ButtonType()
	@FindByLabel(label = "Create new Budget Application")
	public WebElement createNewBudgetApplication;
	@PageWaitAfter.Timed(durationSeconds = 8)
	@ButtonType()
	@FindByLabel(label = "Final Save")
	public WebElement finalSave;
	@LinkType()
	@FindBy(xpath = "//td[contains(@title,'Link to Main Application')]//a")
	public WebElement ApplicationID;
	@TextType()
	@FindBy(xpath = "//td[text()='Direct Costs']/ancestor::div[contains(@class,'pbSubheader')]/img")
	public WebElement DIrectCostExpand;
	@TextType()
	@FindBy(xpath = "(//td[contains(text(),'Member Costs')]/ancestor::div[contains(@class,'pbSubheader')])[1]/img")
	public WebElement MemberCostExpand;
	@TextType()
	@FindBy(xpath = "(//td[contains(text(),'Member Living')]/ancestor::div[contains(@class,'pbSubheader')])[1]/img")
	public WebElement MemeberLivingAllowanceExpand;

	@PageRow()
	public static class MemberLivingTable {
		@ChoiceListType()
		@FindBy(xpath = ".//th[contains(@class,'AccountColumn')]//select")
		public WebElement Account;

		@ButtonType()
		@FindBy(xpath = ".//th[contains(@class,'AddDelete')]//input")
		public WebElement Add;
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "(//td[contains(text(),'Member Living')]/ancestor::div[contains(@class,'pbSubheader')])[1]/following-sibling::div[1]//table//table")
	@PageTable(firstRowContainsHeaders = true, row = MemberLivingTable.class)
	public List<MemberLivingTable> MemberLivingTable;

	@PageRow()
	public static class MemberLivingDataTable {
		
		@TextType()
		@FindBy(xpath = ".//td[5]//input")
		public WebElement InputBox2;
		@TextType()
		@FindBy(xpath = ".//td[6]//input")
		public WebElement InputBox3;
		@TextType()
		@FindBy(xpath = ".//td[10]//input")
		public WebElement InputBox4;
		@TextType()
		@FindBy(xpath = ".//td[11]//input")
		public WebElement InputBox5;
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = "./tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "(//td[contains(text(),'Member Living')]/ancestor::div[contains(@class,'pbSubheader')])[1]/following-sibling::div[1]//table//table//tbody[@id]")
	@PageTable(firstRowContainsHeaders = false, row = MemberLivingDataTable.class)
	public List<MemberLivingDataTable> MemberLivingDataTable;
	@FindBy(xpath = "(//td[contains(text(),'Member Living')]/ancestor::div[contains(@class,'pbSubheader')])[1]/following-sibling::div[1]//input")
	@ButtonType()
	public WebElement addItems;
	@BooleanType()
	@FindByLabel(label = "ACSN 2-Year Half Time Members (Year 1) with Living Allowance")
	public WebElement aCSN2YearHalfTimeMembersYear1WithLivingAllowance;
	@ButtonType()
	@FindByLabel(label = "Add Items")
	public WebElement addItems1;
	@ButtonType()
	@FindBy(name = "j_id0:j_id785:j_id786:j_id788:j_id795:j_id796:j_id801")
	public WebElement addItems2;
	@ButtonType()
	@FindBy(xpath = "//fieldset/input")
	public WebElement addItems11;

}
