package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Consensus Review RL"                                
               , summary=""
               , page="ConsensusReviewRL"
               , namespacePrefix=""
               , object="Expert_Review_Panel__c"
               , connection="OGPO"
     )             
public class ConsensusReviewRL {

	@PageTable(row = LstCR.class)
	@VisualforceBy(componentXPath = "apex:pageBlockTable[@value = \"{!lstCR}\"]")
	public List<LstCR> LstCR;

	@PageRow(byColumn = true)
	public static class LstCR {

		@LinkType()
		@FindBy(xpath = ".//td[contains(@class, \"dataCell\")]/a")
		public WebElement name;
	}
	
}
