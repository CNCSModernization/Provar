package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ReviewerApplicationView"                                
     , summary=""
     , relativeUrl=""
     , connection="ExpertReviewer"
     )             
public class ReviewerApplicationView {

	@TextType()
	@FindBy(xpath = "//th[text()='Mailing City']/following-sibling::td/span")
	public WebElement mailingCity;
	@ButtonType()
	@FindByLabel(label = "Submit")
	public WebElement submit;
	@TextType()
	@FindByLabel(label = "Proposed End Date")
	public WebElement proposedEndDate;
	@ButtonType()
	@FindByLabel(label = "Continue")
	public WebElement continue_;
	@TextType()
	@FindBy(id = "pg:frm1:CustomList:RecAw:RecAwSection:j_id239")
	public WebElement seniorGrantsOfficer;
	@ButtonType()
	@FindByLabel(label = "Recommend for Award")
	public WebElement recommendForAward;
	@TextType()
	@FindBy(id = "pg:frm1:CustomList:RecAw:RecAwSection:POName")
	public WebElement programOfficer;
	@TextType()
	@FindBy(id = "pg:frm1:CustomList:RecAw:RecAwSection:SPOName")
	public WebElement seniorProgramOfficer;
	@TextType()
	@FindBy(id = "pg:frm1:CustomList:RecAw:RecAwSection:j_id238")
	public WebElement grantsOfficer;
	@TextType()
	@FindBy(id = "pg:frm1:CustomList:RecAw:RecAwSection:j_id240")
	public WebElement executiveOfficer;
	@NumericType(decimalPlaces = 2, length = 18)
	@FindByLabel(label = "Total Recommended Amount")
	public WebElement totalRecommendedAmount;
	@ButtonType()
	@FindBy(name = "pg:frm1:CustomList:Pb_block:j_id248:j_id249")
	public WebElement save;
	@ButtonType()
	@FindBy(xpath = "//*[@id=\"pg:frm1:CustomList:j_id75\"]//input[3]")
	public WebElement approveForAward;
			
}
