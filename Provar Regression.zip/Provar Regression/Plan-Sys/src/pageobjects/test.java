package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.provar.core.model.ui.api.UiFacet;
import com.provar.core.testapi.annotations.*;

@Page( title="test"                                
     , summary=""
     , relativeUrl=""
     , connection="Provar"
     )             
public class test {

	@TextType()
	@FindBy(id = "phSearchInput")
	public WebElement search;

	@PageRow()
	public static class Contact {
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//*[@id=\"Contact_body\"]//table")
	@PageTable(firstRowContainsHeaders = true, row = Contact.class)
	public List<Contact> Contact;
			
}
