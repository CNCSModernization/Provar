package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;
import com.provar.plugins.forcedotcom.core.ui.pagecontrols.cke.CkEditor;

@Page(title = "NOFOScreen", summary = "", relativeUrl = "", connection = "POAdmin")
public class NOFOScreen {

	@TextType()
	@FindBy(xpath = "//label[contains(text(),'Corporate Program Name')]/ancestor::td[contains(@class,'labelCol')]/following-sibling::td[1]//span[@class='lookupInput']/a")
	public WebElement CNCS_Corporate_Program__c;
	@TextType()
	@FindByLabel(label = "Project Title")
	public WebElement projectTitle;
	@ChoiceListType(values = { @ChoiceListValue(value = "AA"), @ChoiceListValue(value = "AE"),
			@ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"), @ChoiceListValue(value = "AP"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "BA"), @ChoiceListValue(value = "BM"), @ChoiceListValue(value = "CA"),
			@ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"), @ChoiceListValue(value = "DC"),
			@ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"), @ChoiceListValue(value = "GA"),
			@ChoiceListValue(value = "GU"), @ChoiceListValue(value = "HI"), @ChoiceListValue(value = "IA"),
			@ChoiceListValue(value = "ID"), @ChoiceListValue(value = "IL"), @ChoiceListValue(value = "IN"),
			@ChoiceListValue(value = "JM"), @ChoiceListValue(value = "KS"), @ChoiceListValue(value = "KY"),
			@ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"), @ChoiceListValue(value = "MD"),
			@ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MI"), @ChoiceListValue(value = "MN"),
			@ChoiceListValue(value = "MO"), @ChoiceListValue(value = "MS"), @ChoiceListValue(value = "MT"),
			@ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"), @ChoiceListValue(value = "NE"),
			@ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"), @ChoiceListValue(value = "NM"),
			@ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"), @ChoiceListValue(value = "OH"),
			@ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"), @ChoiceListValue(value = "PA"),
			@ChoiceListValue(value = "PR"), @ChoiceListValue(value = "PW"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "SP"),
			@ChoiceListValue(value = "TN"), @ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UT"),
			@ChoiceListValue(value = "VA"), @ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"),
			@ChoiceListValue(value = "WA"), @ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"),
			@ChoiceListValue(value = "WY"), @ChoiceListValue(value = "XX") })
	@FindByLabel(label = "Project State")
	public WebElement projectState;
	@TextType()
	@FindByLabel(label = "Street Address 1")
	public WebElement streetAddress1;
	@TextType()
	@FindByLabel(label = "City")
	public WebElement city;
	@ChoiceListType(values = { @ChoiceListValue(value = "AA"), @ChoiceListValue(value = "AE"),
			@ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"), @ChoiceListValue(value = "AP"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "CA"), @ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"),
			@ChoiceListValue(value = "DC"), @ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"),
			@ChoiceListValue(value = "FM"), @ChoiceListValue(value = "GA"), @ChoiceListValue(value = "GU"),
			@ChoiceListValue(value = "HI"), @ChoiceListValue(value = "IA"), @ChoiceListValue(value = "ID"),
			@ChoiceListValue(value = "IL"), @ChoiceListValue(value = "IN"), @ChoiceListValue(value = "KS"),
			@ChoiceListValue(value = "KY"), @ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"),
			@ChoiceListValue(value = "MD"), @ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MH"),
			@ChoiceListValue(value = "MI"), @ChoiceListValue(value = "MN"), @ChoiceListValue(value = "MO"),
			@ChoiceListValue(value = "MP"), @ChoiceListValue(value = "MS"), @ChoiceListValue(value = "MT"),
			@ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"), @ChoiceListValue(value = "NE"),
			@ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"), @ChoiceListValue(value = "NM"),
			@ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"), @ChoiceListValue(value = "OH"),
			@ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"), @ChoiceListValue(value = "PA"),
			@ChoiceListValue(value = "PR"), @ChoiceListValue(value = "PW"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "TN"),
			@ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UM"), @ChoiceListValue(value = "UT"),
			@ChoiceListValue(value = "VA"), @ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"),
			@ChoiceListValue(value = "WA"), @ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"),
			@ChoiceListValue(value = "WY") })
	@FindByLabel(label = "State")
	public WebElement state;
	@TextType()
	@FindByLabel(label = "Zip")
	public WebElement zip;
	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save;
	@TextType()
	@FindByLabel(label = "Email")
	public WebElement email;
	@PageWaitAfter.Timed(durationSeconds = 10)
	@ButtonType()
	@FindByLabel(label = "Use Old Address")
	public WebElement useOldAddress;
	@TextType()
	@FindByLabel(label = "Point of Contact")
	public WebElement pointOfContact;
	@ChoiceListType(values = { @ChoiceListValue(value = "0", title = "AL"), @ChoiceListValue(value = "1", title = "AK"), @ChoiceListValue(value = "2", title = "AZ"), @ChoiceListValue(value = "3", title = "AR"), @ChoiceListValue(value = "4", title = "CA"), @ChoiceListValue(value = "5", title = "CO"), @ChoiceListValue(value = "6", title = "CT"), @ChoiceListValue(value = "7", title = "DC"), @ChoiceListValue(value = "8", title = "DE"), @ChoiceListValue(value = "9", title = "FL"), @ChoiceListValue(value = "10", title = "GA"), @ChoiceListValue(value = "11", title = "HI"), @ChoiceListValue(value = "12", title = "ID"), @ChoiceListValue(value = "13", title = "IL"), @ChoiceListValue(value = "14", title = "IN"), @ChoiceListValue(value = "15", title = "IA"), @ChoiceListValue(value = "16", title = "KS"), @ChoiceListValue(value = "17", title = "KY"), @ChoiceListValue(value = "18", title = "LA"), @ChoiceListValue(value = "19", title = "ME"), @ChoiceListValue(value = "20", title = "MD"), @ChoiceListValue(value = "21", title = "MA"), @ChoiceListValue(value = "22", title = "MI"), @ChoiceListValue(value = "23", title = "MN"), @ChoiceListValue(value = "24", title = "MS"), @ChoiceListValue(value = "25", title = "MO"), @ChoiceListValue(value = "26", title = "MT"), @ChoiceListValue(value = "27", title = "NE"), @ChoiceListValue(value = "28", title = "NV"), @ChoiceListValue(value = "29", title = "NH"), @ChoiceListValue(value = "30", title = "NJ"), @ChoiceListValue(value = "31", title = "NM"), @ChoiceListValue(value = "32", title = "NY"), @ChoiceListValue(value = "33", title = "NC"), @ChoiceListValue(value = "34", title = "ND"), @ChoiceListValue(value = "35", title = "OH"), @ChoiceListValue(value = "36", title = "OK"), @ChoiceListValue(value = "37", title = "OR"), @ChoiceListValue(value = "38", title = "PA"), @ChoiceListValue(value = "39", title = "RI"), @ChoiceListValue(value = "40", title = "SC"), @ChoiceListValue(value = "41", title = "SD"), @ChoiceListValue(value = "42", title = "TN"), @ChoiceListValue(value = "43", title = "TX"), @ChoiceListValue(value = "44", title = "UT"), @ChoiceListValue(value = "45", title = "VT"), @ChoiceListValue(value = "46", title = "VA"), @ChoiceListValue(value = "47", title = "WA"), @ChoiceListValue(value = "48", title = "WV"), @ChoiceListValue(value = "49", title = "WI"), @ChoiceListValue(value = "50", title = "WY"), @ChoiceListValue(value = "51", title = "GU"), @ChoiceListValue(value = "52", title = "MP"), @ChoiceListValue(value = "53", title = "PR"), @ChoiceListValue(value = "54", title = "VI") })
	@FindBy(xpath = "//select[@title='State and/or Territories - Available']")
	public WebElement stateAndOrTerritories;
	@LinkType()
	@FindBy(xpath = "//td[contains(@class, \"multiSelectPicklistCell\")]//a[1]")
	public WebElement AddState;
	@TextType()
	@FindByLabel(label = "Counties")
	public WebElement counties;
	@TextType()
	@FindByLabel(label = "Cities")
	public WebElement cities;
	@TextType()
	@FindBy(xpath = "//*[@id=\"cke_j_id0:theForm:j_id2:j_id50:j_id51:j_id55:textAreaDelegate_Executive_Summary__c\"]")
	public CkEditor textAreaDelegate_Executive_Summary__c;
	@TextType()
	@FindBy(xpath = "//*[@id=\"cke_j_id0:theForm:j_id2:j_id50:j_id56:j_id60:textAreaDelegate_Organizational_Capability__c\"]")
	public CkEditor textAreaDelegate_Organizational_Capability__c;
	@LinkType()
	@FindBy(linkText = "2/22/2017")
	public WebElement proposedStartDate;
	@TextType()
	@FindByLabel(label = "Proposed Start Date")
	public WebElement proposedStartDate1;
	@TextType()
	@FindByLabel(label = "Proposed End Date")
	public WebElement proposedStartDate2;
	@TextType()
	@FindBy(xpath = "(//span[@class=\"lookupInput\"]/a)[2]")
	public WebElement projectDirector;
	@TextType()
	@FindBy(xpath = "//div[contains(@class,\"Executive_Summary\")]")
	public CkEditor textAreaDelegate_Executive_Summary__c1;
	
	@TextType()
	@FindBy(xpath = "//div[contains(@class,\"Need\")]")
	public CkEditor textAreaDelegate_Need;
	
	@TextType()
	@FindBy(xpath = "//div[contains(@class,\"Intermediary_Justification\")]")
	public CkEditor textAreaDelegate_Intermediary_Justification;
	
	@TextType()
	@FindBy(xpath = "//div[contains(@class,\"Strengthen_Communities\")]")
	public CkEditor textAreaDelegate_Strengthen_Communities;
	
	@TextType()
	@FindBy(xpath = "//div[contains(@class,\"Program_Design\")]")
	public CkEditor textAreaDelegate_Project_Design__c1;
	
	@TextType()
	@FindBy(xpath = "//div[contains(@class,\"Program_Management\")]")
	public CkEditor textAreaDelegate_Program_Management__c1;
	
	@TextType()
	@FindBy(xpath = "//div[contains(@class,\"Organizational_Capability\")]")
	public CkEditor textAreaDelegate_Organizational_Capability__c1;
	@ChoiceListType(values = { @ChoiceListValue(value = "AA"), @ChoiceListValue(value = "AE"),
			@ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"), @ChoiceListValue(value = "AP"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "CA"), @ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"),
			@ChoiceListValue(value = "DC"), @ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"),
			@ChoiceListValue(value = "FM"), @ChoiceListValue(value = "GA"), @ChoiceListValue(value = "GU"),
			@ChoiceListValue(value = "HI"), @ChoiceListValue(value = "IA"), @ChoiceListValue(value = "ID"),
			@ChoiceListValue(value = "IL"), @ChoiceListValue(value = "IN"), @ChoiceListValue(value = "KS"),
			@ChoiceListValue(value = "KY"), @ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"),
			@ChoiceListValue(value = "MD"), @ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MH"),
			@ChoiceListValue(value = "MI"), @ChoiceListValue(value = "MN"), @ChoiceListValue(value = "MO"),
			@ChoiceListValue(value = "MP"), @ChoiceListValue(value = "MS"), @ChoiceListValue(value = "MT"),
			@ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"), @ChoiceListValue(value = "NE"),
			@ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"), @ChoiceListValue(value = "NM"),
			@ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"), @ChoiceListValue(value = "OH"),
			@ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"), @ChoiceListValue(value = "PA"),
			@ChoiceListValue(value = "PR"), @ChoiceListValue(value = "PW"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "TN"),
			@ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UM"), @ChoiceListValue(value = "UT"),
			@ChoiceListValue(value = "VA"), @ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"),
			@ChoiceListValue(value = "WA"), @ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"),
			@ChoiceListValue(value = "WY") })
	@FindByLabel(label = "State")
	public WebElement state1;
	@TextType()
	@FindByLabel(label = "Project Director")
	public WebElement projectDirector1;
	@ButtonType()
	@FindByLabel(label = "Use Suggested Address")
	public WebElement useSuggestedAddress;
	@ButtonType()
	@FindByLabel(label = "Use Entered Address")
	public WebElement useEnteredAddress;
	@TextType()
	@FindByLabel(label = "Phone")
	public WebElement phone;
	

}
