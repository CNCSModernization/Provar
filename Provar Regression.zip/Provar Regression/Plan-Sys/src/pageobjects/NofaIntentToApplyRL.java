package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title=""                                
               , summary=""
               , page="NofaIntentToApplyRL"
               , namespacePrefix=""
               , object="NOFA__c"
               , connection="PO"
     )             
public class NofaIntentToApplyRL {

	@PageTable(row = ObjList.class)
	@VisualforceBy(componentXPath = "c:relatedlists[1]//apex:pageBlockTable[@id='results']")
	public List<ObjList> ObjList;

	@PageRow(byColumn = true)
	public static class ObjList {

		@LinkType()
		@FindBy(xpath = "//td[contains(@class, \"dataCell\")]/a")
		public WebElement applicationID;
	}
	
}
