package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="AddLocation"                                
     , summary=""
     , relativeUrl=""
     , connection="GranteePortal"
     )             
public class AddLocation {

	@ChoiceListType(values = { @ChoiceListValue(value = "Operating Site"), @ChoiceListValue(value = "Service Location"),
			@ChoiceListValue(value = "Member Lodging"), @ChoiceListValue(value = "Inclement Weather Site") })
	@FindByLabel(label = "Location Type")
	public WebElement locationType;
	@TextType()
	@FindByLabel(label = "Location Name")
	public WebElement locationName;
	@TextType()
	@FindByLabel(label = "Supervisor Name")
	public WebElement supervisorName;
	@TextType()
	@FindByLabel(label = "Supervisor Email")
	public WebElement supervisorEmail;
	@TextType()
	@FindByLabel(label = "Supervisor Phone Number")
	public WebElement supervisorPhoneNumber;
	@TextType()
	@FindByLabel(label = "Street Address 1")
	public WebElement streetAddress1;
	@TextType()
	@FindByLabel(label = "City")
	public WebElement city;
	@TextType()
	@FindByLabel(label = "Zip")
	public WebElement zip;
	@ChoiceListType(values = { @ChoiceListValue(value = "AA"), @ChoiceListValue(value = "AE"),
			@ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"), @ChoiceListValue(value = "AP"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "BA"), @ChoiceListValue(value = "BM"), @ChoiceListValue(value = "CA"),
			@ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"), @ChoiceListValue(value = "DC"),
			@ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"), @ChoiceListValue(value = "GA"),
			@ChoiceListValue(value = "GU"), @ChoiceListValue(value = "HI"), @ChoiceListValue(value = "IA"),
			@ChoiceListValue(value = "ID"), @ChoiceListValue(value = "IL"), @ChoiceListValue(value = "IN"),
			@ChoiceListValue(value = "JM"), @ChoiceListValue(value = "KS"), @ChoiceListValue(value = "KY"),
			@ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"), @ChoiceListValue(value = "MD"),
			@ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MI"), @ChoiceListValue(value = "MN"),
			@ChoiceListValue(value = "MO"), @ChoiceListValue(value = "MS"), @ChoiceListValue(value = "MT"),
			@ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"), @ChoiceListValue(value = "NE"),
			@ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"), @ChoiceListValue(value = "NM"),
			@ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"), @ChoiceListValue(value = "OH"),
			@ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"), @ChoiceListValue(value = "PA"),
			@ChoiceListValue(value = "PR"), @ChoiceListValue(value = "PW"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "SP"),
			@ChoiceListValue(value = "TN"), @ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UT"),
			@ChoiceListValue(value = "VA"), @ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"),
			@ChoiceListValue(value = "WA"), @ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"),
			@ChoiceListValue(value = "WY"), @ChoiceListValue(value = "XX") })
	@FindByLabel(label = "State")
	public WebElement state;
	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save;
	@PageWaitAfter.Timed(durationSeconds = 6)
	@ButtonType()
	@FindByLabel(label = "Use Old Address")
	public WebElement useOldAddress;
	@TextType()
	@FindByLabel(label = "Location EIN")
	public WebElement locationEIN;
	@ButtonType()
	@FindByLabel(label = "Use Entered Address")
	public WebElement useEnteredAddress;
			
}
