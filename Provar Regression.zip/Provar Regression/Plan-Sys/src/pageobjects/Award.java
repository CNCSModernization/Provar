package pageobjects;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page(title = "Award", summary = "", relativeUrl = "", connection = "GranteePortal")
public class Award {

	private WebDriver driver;

	public Award(WebDriver driver) {
		this.driver = driver;
	}

	@ButtonType()
	@FindByLabel(label = "Sign Agreement")
	public WebElement signAgreement;

	@PageWaitAfter.Timed(durationSeconds = 6)
	@LinkType()
	@FindBy(xpath = "//*[@id=\"Page:frm\"]/a[1]")
	public WebElement ClickHereToViewAssurances;

	@PageWaitAfter.Timed(durationSeconds = 6)
	@LinkType()
	@FindBy(xpath = "//*[@id=\"Page:frm\"]//a[2]")
	public WebElement ClickHereToViewCertifications;

	@BooleanType()
	@FindBy(id = "Page:frm:chkbox")
	public WebElement chkbox;

	@TextType()
	@FindBy(id = "Page:frm:name")
	public WebElement name;

	@ButtonType()
	@FindByLabel(label = "Sign and Submit")
	public WebElement signAndSubmit;

	public void scroll() {
		 ((JavascriptExecutor)driver).executeScript("window.scrollTo(0,document.body.scrollHeight)","");

	}

}
