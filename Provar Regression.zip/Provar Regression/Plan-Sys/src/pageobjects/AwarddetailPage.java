package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Awarddetail Page"                                
               , summary=""
               , page="AwarddetailPage"
               , namespacePrefix=""
               , object="Award__c"
               , connection="PO"
     )             
public class AwarddetailPage {

	@ButtonType()
	@VisualforceBy(componentXPath = "apex:pageBlockButtons[2]/apex:commandButton[@action='{!Edit}']")
	public WebElement edit;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:pageBlockButtons[2]/apex:commandButton[@action='{!esign}'][@value='Certify & Send to Organization for e-Signature']")
	public WebElement certifyAndSendToOrganizationForESignature;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:pageBlockButtons[2]/apex:commandButton[@action='{!SignAgreementtoXO}']")
	public WebElement signAgreementAndSendToXO;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!openPopup}']")
	public WebElement addRecord;
	@PageTable(row = LstFundingSource.class)
	@VisualforceBy(componentXPath = "apex:pageBlockTable[@value = \"{!lstFundingSource}\"]")
	public List<LstFundingSource> LstFundingSource;
	@PageRow(byColumn = true)
	public static class LstFundingSource {

		@LinkType()
		@VisualforceBy(componentXPath = "apex:column[not(@value)][1]")
		public WebElement name;
	}
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!updateFundCommitment}']")
	public WebElement updateFundCommitment;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:pageBlockButtons[2]/apex:commandButton[@action='{!CertifytoSGO}']")
	public WebElement certifySendToSGO;
	@PageTable(row = LstFundObligation.class)
	@VisualforceBy(componentXPath = "apex:pageBlockTable[@value = \"{!lstFundObligation}\"]")
	public List<LstFundObligation> LstFundObligation;
	@PageRow(byColumn = true)
	public static class LstFundObligation {

		@TextType()
		@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!fundObligationRec.Change__c}\"]")
		public WebElement change;
		@TextType()
		@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!fundObligationRec.Change__c}\"]")
		public WebElement change1;
	}
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!updateObligationFundTransaction}']")
	public WebElement updateFundObligation;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:pageBlockButtons[2]/apex:commandButton[@action='{!AwardApp}']")
	public WebElement award;
	@VisualforceBy(componentXPath = "apex:pageblocksection[3]/apex:outputField[@value = \"{!awarddetail .Grant_Status__c}\"]")
	@SalesforceField(name = "Grant_Status__c", object = "Award__c")
	public WebElement grantStatus;
	@PageTable(row = LstFundCommitment.class)
	@VisualforceBy(componentXPath = "apex:pageBlockTable[@value = \"{!lstFundCommitment}\"]")
	public List<LstFundCommitment> LstFundCommitment;
	@PageRow(byColumn = true)
	public static class LstFundCommitment {

		@TextType()
		@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!fundCommitmentRec.Change__c}\"]")
		public WebElement change;
		@TextType()
		@FindBy(xpath = ".//td[9]//input")
		public WebElement change1;
	}
	@ButtonType()
	@FindByLabel(label = "Amend")
	public WebElement amend;
	
}
