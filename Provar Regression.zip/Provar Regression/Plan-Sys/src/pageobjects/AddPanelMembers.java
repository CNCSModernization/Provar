package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Add Panel Members"                                
               , summary=""
               , page="AddPanelMembers"
               , namespacePrefix=""
               , object=""
               , connection="OGPO"
     )             
public class AddPanelMembers {

	@PageRow()
	public static class Table {

		@BooleanType()
		@FindBy(xpath = ".//input[contains(@class, \"contactCb\")]")
		public WebElement Reviewer;
	}

	@FindBy(id = "page:form:pb:results:j_id36:tb")
	@PageTable(firstRowContainsHeaders = false, row = Table.class)
	public List<Table> table;
	@ButtonType()
	@FindByLabel(label = "Process Selected")
	public WebElement processSelected;
	
}
