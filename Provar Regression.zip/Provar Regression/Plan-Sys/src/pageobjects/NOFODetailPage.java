package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.provar.core.model.ui.api.UiFacet;
import com.provar.core.testapi.annotations.*;

@SalesforcePage(title = "NOFO Detail Page", page = "NofoDetailPage", object = "NOFA__c", connection = "Admin")
public class NOFODetailPage {

	@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!nofa.Status__c}\"]")
	@SalesforceField(name = "Status__c", object = "NOFA__c")
	public WebElement nOFOStatus;

	@ButtonType()
	@FindByLabel(label = "New Funding Source")
	public WebElement newFundingSource;

	@PageRow()
	public static class FundingSource {
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//h3[contains(text(),'Funding Source')]/ancestor::div[@class='pbHeader']/following-sibling::div[@class='pbBody']//table")
	@PageTable(firstRowContainsHeaders = true, row = FundingSource.class)
	public List<FundingSource> FundingSource;

	@ButtonType()
	@FindByLabel(label = "New Action Report")
	public WebElement newActionReport;

	@PageRow()
	public static class ActionReport {
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//h3[contains(text(),'Action Reports')]/ancestor::div[@class='pbHeader']/following-sibling::div[@class='pbBody']//table")
	@PageTable(firstRowContainsHeaders = true, row = FundingSource.class)
	public List<ActionReport> ActionReport;

	@ButtonType()
	@FindByLabel(label = "Submit for Approval")
	public WebElement submitForApproval;

	@ButtonType()
	@FindBy(xpath = "//input[@name=\"piSubmit\"]")
	public WebElement submitForApproval1;

	@VisualforceBy(componentXPath = "apex:outputField[@id='Test1']")
	@SalesforceField(name = "Name", object = "NOFA__c")
	public WebElement nOFORFPID;

	@PageRow()
	public static class ApprovalHistory {

		@LinkType()
		@FindBy(xpath = ".//td[3]/a")
		public WebElement assignedTo;

		@LinkType()
		@FindBy(xpath = ".//td[1]/a[2]")
		public WebElement action;

		@LinkType()
		@FindBy(linkText = "Approve / Reject")
		public WebElement action1;
	}

	@FacetFindBys(value = {
			@FacetFindBy(findBy = @FindBy(xpath = ".//tr[contains(@class,'Row') and not(contains(@class,'extra'))]"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//div[contains(@class, \"relatedProcessHistory\")]/div/div[2]/table")
	@PageTable(firstRowContainsHeaders = true, row = ApprovalHistory.class)
	public List<ApprovalHistory> ApprovalHistory;

	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!edit}']")
	public WebElement edit;

	@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!nofa.NOFA_Active_Inactive__c}\"]")
	@SalesforceField(name = "NOFA_Active_Inactive__c", object = "NOFA__c")
	public WebElement openToApplications;

	@PageRow()
	public static class IntentToApply {

		@LinkType()
		@FindBy(xpath = ".//td[2]/a")
		public WebElement applicationID;
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//label[contains(text(),'Intent to Apply')]/../following-sibling::div//table")
	@PageTable(firstRowContainsHeaders = true, row = IntentToApply.class)
	public List<IntentToApply> IntentToApply;

	@ChoiceListType(values = { @ChoiceListValue(value = "ACSN - Cost Reimbursement"),
			@ChoiceListValue(value = "ACSN - Fixed Amount"), @ChoiceListValue(value = "er"),
			@ChoiceListValue(value = "FGP/SCP - Cost Reimbursement"),
			@ChoiceListValue(value = "FGP/SCP - Fixed Amount"),
			@ChoiceListValue(value = "Melissa's Sample Budget Form"), @ChoiceListValue(value = "MLK"),
			@ChoiceListValue(value = "Other"), @ChoiceListValue(value = "Praveen"),
			@ChoiceListValue(value = "Program Grant Budget"), @ChoiceListValue(value = "RSVP"),
			@ChoiceListValue(value = "SIF"), @ChoiceListValue(value = "Standard Budget"),
			@ChoiceListValue(value = "Support Grant Budget"), @ChoiceListValue(value = "Test Beta"),
			@ChoiceListValue(value = "VISTA"), @ChoiceListValue(value = "VISTA Standard") })
	@FindBy(xpath = "//select[contains(@id, \"multiselectPanel:leftList\")]")
	public WebElement availableBudgetForm;

	@FindBy(xpath = "//a[contains(@href,\"moveSelectedOptions\") and contains(@id,'btnRight')]")
	@LinkType()
	public WebElement btnRight;

	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!save}']")
	public WebElement configure;

	@TextType()
	@FindBy(xpath = "//img[contains(@class, \"rightArrowIcon\")]")
	public WebElement btnRight1;

	@ButtonType()
	@FindByLabel(label = "New Match Schedule")
	public WebElement newMatchSchedule;

	@LinkType()
	@FindBy(linkText = "Logout")
	public WebElement logout;

	@LinkType()
	@FindBy(linkText = "Configure")
	public WebElement configure1;

	@TextType()
	@FindByLabel(label = "NOFO/RFP ID", labelType = LabelType.PrecedingCell)
	public WebElement nOFORFPID1;




}
