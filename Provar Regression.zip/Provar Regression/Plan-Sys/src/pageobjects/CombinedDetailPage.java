package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( page="CombinedDetailPage"
               , object="Application3__c"
               , connection="GranteePortal"
     )             
public class CombinedDetailPage {

	@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!Application3__c.Primary_Focus_Area__c}\"]")
	@SalesforceField(name = "Primary_Focus_Area__c", object = "Application3__c")
	public WebElement primaryFocusArea;
	@PageWaitAfter.Timed(durationSeconds = 5)
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:pageBlock[@id='pgbtnid']//apex:commandButton[@value='Withdraw']")
	public WebElement withdraw;
	@PageWait.Timed(durationSeconds = 5)
	@VisualforceBy(componentXPath = "apex:pageBlockSection[@id='pbs']/apex:outputField[@value = \"{!Application3__c.Grantee_Status__c}\"]")
	@SalesforceField(name = "Grantee_Status__c", object = "Application3__c")
	public WebElement applicationStatus;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!reopenIntent}']")
	public WebElement reOpen;
	
	@VisualforceBy(componentXPath = "apex:pageBlockSection[4]/apex:outputField[@value = \"{!applicationInput.State_and_or_Territories__c}\"]")
	@SalesforceField(name = "State_and_or_Territories__c", object = "Application3__c")
	public WebElement stateAndOrTerritories;
	@VisualforceBy(componentXPath = "apex:pageBlockSection[@id='pbsec']/apex:outputField[@value = \"{!Application3__c.Corporate_Program__c}\"][1]")
	@SalesforceField(name = "Corporate_Program__c", object = "Application3__c")
	public WebElement corporateProgram1;
	@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!Application3__c.Corporate_Program__c}\"][2]")
	@SalesforceField(name = "Corporate_Program__c", object = "Application3__c")
	public WebElement corporateProgram;
	@TextType()
	@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!Application3__c.NOFA_RFP__r.Concept_Paper_Due_Date__c}\"]")
	public WebElement conceptPaperDueDate;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!Approve}']")
	public WebElement approve;
	@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!applicationInput.Type_of_Application__c}\"]")
	@SalesforceField(name = "Type_of_Application__c", object = "Application3__c")
	public WebElement type;
	@VisualforceBy(componentXPath = "apex:outputField[@value = \"{!applicationInput.Grantee_Status__c}\"]")
	@SalesforceField(name = "Grantee_Status__c", object = "Application3__c")
	public WebElement applicationStatus1;
	@TextType()
	@FindBy(id = "phSearchInput")
	public WebElement search;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!RecAwardsMethod}']")
	public WebElement recommendForAward;
	@VisualforceBy(componentXPath = "apex:inputField[@id='POName']")
	@SalesforceField(name = "Program_Officer__c", object = "Application3__c")
	public WebElement programOfficer;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Grants_Officer__c}\"]")
	@SalesforceField(name = "Grants_Officer__c", object = "Application3__c")
	public WebElement grantsOfficer;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Executive_Officer__c}\"]")
	@SalesforceField(name = "Executive_Officer__c", object = "Application3__c")
	public WebElement executiveOfficer;
	@VisualforceBy(componentXPath = "apex:inputField[@id='SPOName']")
	@SalesforceField(name = "Senior_Program_Officer__c", object = "Application3__c")
	public WebElement seniorProgramOfficer;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Senior_Grants_Officer__c}\"]")
	@SalesforceField(name = "Senior_Grants_Officer__c", object = "Application3__c")
	public WebElement seniorGrantsOfficer;
	@VisualforceBy(componentXPath = "apex:inputField[@id='RAA']")
	@SalesforceField(name = "Recommended_Award_Amount__c", object = "Application3__c")
	public WebElement totalRequestedAmount;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!applicationInput.Total_Recommended_Amount__c}\"]")
	@SalesforceField(name = "Total_Recommended_Amount__c", object = "Application3__c")
	public WebElement totalRecommendedAmount;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!ApprovedforAward}']")
	public WebElement save;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!ApproveforAward}']")
	public WebElement approveForAward;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!appEdit}']")
	public WebElement edit;
	@VisualforceBy(componentXPath = "apex:pageBlock[@id='CustomList']/apex:pageBlockSection[@id='pbsec']/apex:outputField[@value = \"{!Application3__c.Name}\"]")
	@SalesforceField(name = "Name", object = "Application3__c")
	public WebElement applicationID;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:pageBlock[@id='CustomList']//apex:commandButton[@action='{!Submitdetail}']")
	public WebElement submit;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!AddLocations}']")
	public WebElement addLocations;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!contApp}'][@value='Apply for Continuation Award']")
	public WebElement applyForContinuationAward;
	@TextType()
	@FindBy(id = "pg:frm1:CustomList:RecAw:RecAwSection:j_id240")
	public WebElement grantsOfficer1;
	@TextType()
	@FindBy(name = "pg:frm1:CustomList:RecAw:RecAwSection:j_id242")
	public WebElement seniorGrantsOfficer1;
	@TextType()
	@FindBy(name = "pg:frm1:CustomList:RecAw:RecAwSection:j_id241")
	public WebElement grantsOfficer2;
	@TextType()
	@FindByLabel(label = "Total Recommended Amount")
	public WebElement executiveOfficer1;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:pageBlock[@id='CustomList']//apex:commandButton[@action='{!Submitdetail}']")
	public WebElement submit1;
	
}
