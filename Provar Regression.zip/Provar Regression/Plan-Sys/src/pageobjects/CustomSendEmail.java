package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Custom Send Email"                                
               , summary=""
               , page="CustomSendEmail"
               , namespacePrefix=""
               , object=""
               , connection="PO"
     )             
public class CustomSendEmail {

	@TextType()
	@VisualforceBy(componentXPath = "apex:form//h1[contains(@class, \"pageType\")]")
	public WebElement PageDetail;
	@TextType()
	@VisualforceBy(componentXPath = "apex:inputText[@id='To']")
	public WebElement to;
	@TextType()
	@VisualforceBy(componentXPath = "apex:inputText[@id='Subject']")
	public WebElement subject;
	@TextType()
	@VisualforceBy(componentXPath = "apex:inputTextarea[@id='Body']")
	public WebElement body;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!sendEmails}']")
	public WebElement send;
	
}
