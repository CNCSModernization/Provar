package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;
import com.provar.plugins.forcedotcom.core.ui.pagecontrols.cke.CkEditor;

@SalesforcePage( title="NOFO Edit Create"                                
               , page="NofoEditCreate"
               , object="NOFA__c"
               , connection="Admin"
     )             
public class NOFOEditCreate {

	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.NOFA_name__c}\"]")
	@SalesforceField(name = "NOFA_name__c", object = "NOFA__c")
	public WebElement NOFA_name;
	@TextType()
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.NOFA_RFP_Summary__c}\"]")
	@SalesforceField(object = "NOFA__c")
	public WebElement NOFA_RFP_Summary;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.CNCS_Corporate_Program__c}\"]")
	@SalesforceField(name = "CNCS_Corporate_Program__c", object = "NOFA__c")
	public WebElement Corporate_Program;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.NOFA_Type__c}\"]")
	@SalesforceField(name = "NOFA_Type__c", object = "NOFA__c")
	public WebElement NOFA_Type;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Program_Description__c}\"]")
	@SalesforceField(name = "Program_Description__c", object = "NOFA__c")
	public WebElement Program_Description;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.USA_Spending_Site__c}\"]")
	@SalesforceField(name = "USA_Spending_Site__c", object = "NOFA__c")
	public WebElement USA_Spending_Site;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.CFDA_Number__c}\"]")
	@SalesforceField(name = "CFDA_Number__c", object = "NOFA__c")
	public WebElement CFDA_Number;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Issuing_Officer__c}\"]")
	@SalesforceField(name = "Issuing_Officer__c", object = "NOFA__c")
	public WebElement Issuing_Officer;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Allow_Prime_Applicants_and_Sub_Applicant__c}\"]")
	@SalesforceField(name = "Allow_Prime_Applicants_and_Sub_Applicant__c", object = "NOFA__c")
	public WebElement allowPrimeAndSubApplications;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Notification_of_Intent_to_Apply_Required__c}\"]")
	@SalesforceField(name = "Notification_of_Intent_to_Apply_Required__c", object = "NOFA__c")
	public WebElement Notification_of_Intent_to_Apply;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Allow_Concept_Paper__c}\"]")
	@SalesforceField(name = "Allow_Concept_Paper__c", object = "NOFA__c")
	public WebElement Allow_Concept_Paper;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Concept_Paper_Due_Date__c}\"]")
	@SalesforceField(name = "Concept_Paper_Due_Date__c", object = "NOFA__c")
	public WebElement conceptPaperDeadline;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Application_Submission_Instructions__c}\"]")
	@SalesforceField(name = "Application_Submission_Instructions__c", object = "NOFA__c")
	public CkEditor textAreaDelegate_Application_Submission_Instructions__c;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Applications_due_date__c}\"]")
	@SalesforceField(name = "Applications_due_date__c", object = "NOFA__c")
	public WebElement Applications_due_date;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Sub_Budgets_for_Multi_Year_Grants__c}\"]")
	@SalesforceField(name = "Sub_Budgets_for_Multi_Year_Grants__c", object = "NOFA__c")
	public WebElement Sub_Budgets_for_Multi_Year_Grants;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Cash_Grants_Awards__c}\"]")
	@SalesforceField(name = "Cash_Grants_Awards__c", object = "NOFA__c")
	public WebElement Cash_Grants;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Fiscal_Yr__c}\"]")
	@SalesforceField(name = "Fiscal_Yr__c", object = "NOFA__c")
	public WebElement Fiscal_Yr;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Max_of_Award_Years__c}\"]")
	@SalesforceField(name = "Max_of_Award_Years__c", object = "NOFA__c")
	public WebElement Max_of_Award_Years;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!save}']")
	public WebElement save;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.NOFA_Active_Inactive__c}\"]")
	@SalesforceField(name = "NOFA_Active_Inactive__c", object = "NOFA__c")
	public WebElement openToApplications;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Concept_Paper_Submission_Instructions__c}\"]")
	@SalesforceField(name = "Concept_Paper_Submission_Instructions__c", object = "NOFA__c")
	public CkEditor textAreaDelegate_Concept_Paper_Submission_Instructions__c;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Intent_to_Apply_Submission_Instructions__c}\"]")
	@SalesforceField(name = "Intent_to_Apply_Submission_Instructions__c", object = "NOFA__c")
	public CkEditor textAreaDelegate_Intent_to_Apply_Submission_Instructions__c;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Intent_to_Apply_Due_Date__c}\"]")
	@SalesforceField(name = "Intent_to_Apply_Due_Date__c", object = "NOFA__c")
	public WebElement intentToApplyDeadline;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Max_of_Sub_Budgets__c}\"]")
	@SalesforceField(name = "Max_of_Sub_Budgets__c", object = "NOFA__c")
	public WebElement maximumNumberOfBudgets;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Performance_Measures__c}\"]")
	@SalesforceField(name = "Performance_Measures__c", object = "NOFA__c")
	public WebElement performanceMeasures;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Application_Input_Deadline__c}\"]")
	@SalesforceField(name = "Application_Input_Deadline__c", object = "NOFA__c")
	public WebElement applicationInputDeadline;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Review_Cycle__c}\"]")
	@SalesforceField(name = "Review_Cycle__c", object = "NOFA__c")
	public WebElement reviewCycle;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Cooperative_Agreement__c}\"]")
	@SalesforceField(name = "Cooperative_Agreement__c", object = "NOFA__c")
	public WebElement cooperativeAgreement;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.State_Commission_Input_Application__c}\"]")
	@SalesforceField(name = "State_Commission_Input_Application__c", object = "NOFA__c")
	public WebElement stateCommissionInputApplication;
	@BooleanType()
	@FindByLabel(label = "Organizational Capability")
	public WebElement organizationalCapability;
	@BooleanType()
	@FindByLabel(label = "Executive Summary")
	public WebElement executiveSummary;
	@BooleanType()
	@FindByLabel(label = "Intermediary Justification")
	public WebElement intermediaryJustification;
	@BooleanType()
	@FindByLabel(label = "Need")
	public WebElement need;
	@BooleanType()
	@FindByLabel(label = "Strengthening Communities")
	public WebElement strengtheningCommunities;
	@BooleanType()
	@FindByLabel(label = "Education")
	public WebElement education;
	@BooleanType()
	@FindByLabel(label = "Veterans & Military Families")
	public WebElement veteransAndMilitaryFamilies;
	@BooleanType()
	@FindByLabel(label = "Healthy Futures")
	public WebElement healthyFutures;
	@BooleanType()
	@FindByLabel(label = "Economic Opportunities")
	public WebElement economicOpportunities;
	@BooleanType()
	@FindByLabel(label = "Disaster Services")
	public WebElement disasterServices;
	@BooleanType()
	@FindByLabel(label = "Environmental Stewardship")
	public WebElement environmentalStewardship;
	@BooleanType()
	@FindByLabel(label = "Infrastructure Improvement")
	public WebElement infrastructureImprovement;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Characteristics_and_Priorities_cp__c}\"]")
	@SalesforceField(name = "Characteristics_and_Priorities_cp__c", object = "NOFA__c")
	public WebElement characteristicsAndPriorities;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Target_Populations_CP__c}\"]")
	@SalesforceField(name = "Target_Populations_CP__c", object = "NOFA__c")
	public WebElement targetPopulations;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.VISTA__c}\"]")
	@SalesforceField(name = "VISTA__c", object = "NOFA__c")
	public WebElement vISTA;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Application_Maximum_Characters__c}\"]")
	@SalesforceField(name = "Application_Maximum_Characters__c", object = "NOFA__c")
	public WebElement applicationMaximumCharacters;
	@BooleanType()
	@FindByLabel(label = "Amendment Justification")
	public WebElement amendmentJustification;
	@BooleanType()
	@FindByLabel(label = "Continuation Changes")
	public WebElement continuationChanges;
	@BooleanType()
	@FindByLabel(label = "Clarification Summary")
	public WebElement clarificationSummary;
	@BooleanType()
	@FindByLabel(label = "Education")
	public WebElement education1;
	@BooleanType()
	@FindByLabel(label = "Infrastructure Improvement")
	public WebElement infrastructureImprovement1;
	@BooleanType()
	@FindByLabel(label = "Veterans & Military Families")
	public WebElement veteransAndMilitaryFamilies1;
	@BooleanType()
	@FindByLabel(label = "Disaster Services")
	public WebElement disasterServices1;
	@BooleanType()
	@FindByLabel(label = "Healthy Futures")
	public WebElement healthyFutures1;
	@BooleanType()
	@FindByLabel(label = "Economic Opportunities")
	public WebElement economicOpportunities1;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Target_Populations__c}\"]")
	@SalesforceField(name = "Target_Populations__c", object = "NOFA__c")
	public WebElement targetPopulations1;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Characteristics_and_Priorities__c}\"]")
	@SalesforceField(name = "Characteristics_and_Priorities__c", object = "NOFA__c")
	public WebElement characteristicsAndPriorities1;
	@BooleanType()
	@FindByLabel(label = "EIN Information")
	public WebElement eINInformation;
	@BooleanType()
	@FindByLabel(label = "Site Type and Summer Associates")
	public WebElement siteTypeAndSummerAssociates;
	@ChoiceListType(values = { @ChoiceListValue(value = "Yes"), @ChoiceListValue(value = "No") })
	@FindByLabel(label = "Require Location EIN")
	public WebElement requireLocationEIN;
	@ChoiceListType(values = { @ChoiceListValue(value = "Yes"), @ChoiceListValue(value = "No") })
	@FindByLabel(label = "Multi-State")
	public WebElement multiState;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.Required__c}\"]")
	@SalesforceField(name = "Required__c", object = "NOFA__c")
	public WebElement requiredWithValidation;
	@ChoiceListType(values = { @ChoiceListValue(value = "Yes"), @ChoiceListValue(value = "No") })
	@FindByLabel(label = "Member Enrollment Dates")
	public WebElement memberEnrollmentDates;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.NOFA_RFP_Summary_TA__c}\"]")
	@SalesforceField(name = "NOFA_RFP_Summary_TA__c", object = "NOFA__c")
	public WebElement NOFO_Summery_Field;
	@BooleanType()
	@FindByLabel(label = "Economic Opportunity")
	public WebElement economicOpportunity;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.SC_Other__c}\"]")
	@SalesforceField(name = "SC_Other__c", object = "NOFA__c")
	public WebElement sC;
	@VisualforceBy(componentXPath = "apex:inputField[@value = \"{!nofa.S_N__c}\"]")
	@SalesforceField(name = "S_N__c", object = "NOFA__c")
	public WebElement sAndN;
	@BooleanType()
	@FindByLabel(label = "Project Design")
	public WebElement projectDesign;
	@BooleanType()
	@FindByLabel(label = "Project Management")
	public WebElement projectManagement;
	@BooleanType()
	@FindByLabel(label = "Other")
	public WebElement other;
	@BooleanType()
	@FindByLabel(label = "Energy Conservation")
	public WebElement energyConservation;
	@BooleanType()
	@FindByLabel(label = "School Information")
	public WebElement schoolInformation;
	@BooleanType()
	@FindByLabel(label = "Additional Operating Site Information")
	public WebElement additionalOperatingSiteInformation;
	@BooleanType()
	@FindByLabel(label = "Intermediary Justification")
	public WebElement intermediaryJustification1;
	@BooleanType()
	@FindByLabel(label = "Safety and Security")
	public WebElement safetyAndSecurity;
	@BooleanType()
	@FindByLabel(label = "Need")
	public WebElement need1;
	
}
