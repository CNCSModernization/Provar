package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ReviewerApplication"                                
     , summary=""
     , relativeUrl=""
     , connection="ExpertReviewer"
     )             
public class ReviewerApplication {

	@TextType()
	@FindBy(xpath = "//th[text()='Status']/following-sibling::td/span")
	public WebElement status;
	@ButtonType()
	@FindByLabel(label = "Edit")
	public WebElement edit;
	@TextType()
	@FindByLabel(label = "Email (Username)")
	public WebElement emailUsername;
	@TextType()
	@FindByLabel(label = "Mailing Street Address 1")
	public WebElement mailingStreetAddress1;
	@TextType()
	@FindByLabel(label = "Mailing City")
	public WebElement mailingCity;
	@ChoiceListType(values = { @ChoiceListValue(value = "AA"), @ChoiceListValue(value = "AE"),
			@ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"), @ChoiceListValue(value = "AP"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "CA"), @ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"),
			@ChoiceListValue(value = "DC"), @ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"),
			@ChoiceListValue(value = "FM"), @ChoiceListValue(value = "GA"), @ChoiceListValue(value = "GU"),
			@ChoiceListValue(value = "HI"), @ChoiceListValue(value = "IA"), @ChoiceListValue(value = "ID"),
			@ChoiceListValue(value = "IL"), @ChoiceListValue(value = "IN"), @ChoiceListValue(value = "KS"),
			@ChoiceListValue(value = "KY"), @ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"),
			@ChoiceListValue(value = "MD"), @ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MH"),
			@ChoiceListValue(value = "MI"), @ChoiceListValue(value = "MN"), @ChoiceListValue(value = "MO"),
			@ChoiceListValue(value = "MP"), @ChoiceListValue(value = "MS"), @ChoiceListValue(value = "MT"),
			@ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"), @ChoiceListValue(value = "NE"),
			@ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"), @ChoiceListValue(value = "NM"),
			@ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"), @ChoiceListValue(value = "OH"),
			@ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"), @ChoiceListValue(value = "PA"),
			@ChoiceListValue(value = "PR"), @ChoiceListValue(value = "PW"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "TN"),
			@ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UM"), @ChoiceListValue(value = "UT"),
			@ChoiceListValue(value = "VA"), @ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"),
			@ChoiceListValue(value = "WA"), @ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"),
			@ChoiceListValue(value = "WY") })
	@FindByLabel(label = "Mailing State")
	public WebElement mailingState;
	@ChoiceListType(values = { @ChoiceListValue(value = "AA"), @ChoiceListValue(value = "AE"),
			@ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"), @ChoiceListValue(value = "AP"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "BA"), @ChoiceListValue(value = "BM"), @ChoiceListValue(value = "CA"),
			@ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"), @ChoiceListValue(value = "DC"),
			@ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"), @ChoiceListValue(value = "GA"),
			@ChoiceListValue(value = "GU"), @ChoiceListValue(value = "HI"), @ChoiceListValue(value = "IA"),
			@ChoiceListValue(value = "ID"), @ChoiceListValue(value = "IL"), @ChoiceListValue(value = "IN"),
			@ChoiceListValue(value = "JM"), @ChoiceListValue(value = "KS"), @ChoiceListValue(value = "KY"),
			@ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"), @ChoiceListValue(value = "MD"),
			@ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MI"), @ChoiceListValue(value = "MN"),
			@ChoiceListValue(value = "MO"), @ChoiceListValue(value = "MS"), @ChoiceListValue(value = "MT"),
			@ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"), @ChoiceListValue(value = "NE"),
			@ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"), @ChoiceListValue(value = "NM"),
			@ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"), @ChoiceListValue(value = "OH"),
			@ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"), @ChoiceListValue(value = "PA"),
			@ChoiceListValue(value = "PR"), @ChoiceListValue(value = "PW"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "SP"),
			@ChoiceListValue(value = "TN"), @ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UT"),
			@ChoiceListValue(value = "VA"), @ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"),
			@ChoiceListValue(value = "WA"), @ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"),
			@ChoiceListValue(value = "WY") })
	@FindByLabel(label = "State of Residence")
	public WebElement stateOfResidence;
	@ChoiceListType(values = { @ChoiceListValue(value = "CNCS Website (NationalService.gov)"),
			@ChoiceListValue(value = "Email/recruitment flyer"),
			@ChoiceListValue(value = "Federal Agency or Other Federal Entity"),
			@ChoiceListValue(value = "Listserv or Newsletter"), @ChoiceListValue(value = "Other"),
			@ChoiceListValue(value = "Recommended by friend or colleague"), @ChoiceListValue(value = "Social Media") })
	@FindByLabel(label = "How did you hear about CNCS Reviews?")
	public WebElement howDidYouHearAboutCNCSReviews;
	@TextType()
	@FindByLabel(label = "Publication Type")
	public WebElement publicationType;
	@ChoiceListType(values = { @ChoiceListValue(value = "Primary Author/Lead Contributor"),
			@ChoiceListValue(value = "Contributor"), @ChoiceListValue(value = "Editor") })
	@FindByLabel(label = "Role in Publication")
	public WebElement roleInPublication;
	@TextType()
	@FindByLabel(label = "Publication Title")
	public WebElement publicationTitle;
	@TextType()
	@FindByLabel(label = "Date of Publication")
	public WebElement dateOfPublication;
	@TextType()
	@FindByLabel(label = "Publication Description or Comments")
	public WebElement publicationDescriptionOrComments;
	@TextType()
	@FindBy(xpath = "//span[@class=\"lookupInput\"]/a")
	public WebElement institutionOfHigherEducation;
	@TextType()
	@FindByLabel(label = "From")
	public WebElement from;
	@TextType()
	@FindByLabel(label = "To")
	public WebElement to;
	@ChoiceListType(values = { @ChoiceListValue(value = "College/University"),
			@ChoiceListValue(value = "Technical/Vocational"), @ChoiceListValue(value = "Other") })
	@FindByLabel(label = "Organization Type")
	public WebElement organizationType;
	@TextType()
	@FindByLabel(label = "Area(s) of Study")
	public WebElement areaSOfStudy;
	@ChoiceListType(values = { @ChoiceListValue(value = "Less Than High School"),
			@ChoiceListValue(value = "High School Diploma/GED"),
			@ChoiceListValue(value = "Technical School/ Apprenticeship/ Vocational"),
			@ChoiceListValue(value = "Some College"), @ChoiceListValue(value = "Associates Degree (AA)"),
			@ChoiceListValue(value = "College Graduate"),
			@ChoiceListValue(value = "Graduate Degree (e.g. MA, PhD, MD, JD)") })
	@FindByLabel(label = "Highest Completed Level of Education")
	public WebElement highestCompletedLevelOfEducation;
	@TextType()
	@FindBy(xpath = "//tr[4]/td[2]/input")
	public WebElement institutionOfHigherEducation1;
	@TextType()
	@FindByLabel(label = "Degree Obtained")
	public WebElement degreeObtained;
	@BooleanType()
	@FindByLabel(label = "Currently Enrolled")
	public WebElement currentlyEnrolled;
	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save;
	@ChoiceListType(values = { @ChoiceListValue(value = "College/University"),
			@ChoiceListValue(value = "Technical/Vocational"), @ChoiceListValue(value = "Other") })
	@FindByLabel(label = "Organization Type")
	public WebElement organizationType1;
	@TextType()
	@FindByLabel(label = "Area(s) of Study")
	public WebElement areaSOfStudy1;
	@TextType()
	@FindByLabel(label = "Employer/Organization")
	public WebElement employerOrganization;
	@ChoiceListType(values = { @ChoiceListValue(value = "Community-Based Nonprofit Organization"),
			@ChoiceListValue(value = "Early Learning Education"), @ChoiceListValue(value = "Elementary Education"),
			@ChoiceListValue(value = "Faith-Based Organization"), @ChoiceListValue(value = "Federal Agency"),
			@ChoiceListValue(value = "Local or State Agency"), @ChoiceListValue(value = "Local or State Organization"),
			@ChoiceListValue(value = "Municipal Agency"), @ChoiceListValue(value = "National Nonprofit Organization"),
			@ChoiceListValue(value = "Other"), @ChoiceListValue(value = "Postsecondary Education"),
			@ChoiceListValue(value = "Secondary Education"), @ChoiceListValue(value = "VOAD"),
			@ChoiceListValue(value = "Volunteer Center") })
	@FindByLabel(label = "Organization Type")
	public WebElement organizationType2;
	@ChoiceListType(values = { @ChoiceListValue(value = "Capacity Building"),
			@ChoiceListValue(value = "Disaster Services"), @ChoiceListValue(value = "Economic Opportunity"),
			@ChoiceListValue(value = "Education"), @ChoiceListValue(value = "Environmental Stewardship"),
			@ChoiceListValue(value = "Evaluation"), @ChoiceListValue(value = "Healthy Futures"),
			@ChoiceListValue(value = "National Service"), @ChoiceListValue(value = "Veterans and Military Families"),
			@ChoiceListValue(value = "Youth Development") })
	@FindByLabel(label = "Expertise")
	public WebElement expertise;
	@ChoiceListType(values = { @ChoiceListValue(value = "Professional"), @ChoiceListValue(value = "Volunteer") })
	@FindByLabel(label = "Experience Type")
	public WebElement experienceType;
	@TextType()
	@FindByLabel(label = "Work Description")
	public WebElement workDescription;
	@TextType()
	@FindBy(xpath = "//h3[contains(text(),'Employment')]/../following-sibling::div//label[text()='From']/../following-sibling::td[1]//input")
	public WebElement from1;
	@TextType()
	@FindBy(xpath = "//h3[contains(text(),'Employment')]/../following-sibling::div//label[text()='To']/../following-sibling::td[1]//input")
	public WebElement EmpTo;
	@ChoiceListType(values = { @ChoiceListValue(value = "Adult Education & Literacy"),
			@ChoiceListValue(value = "After School Programs"), @ChoiceListValue(value = "Civic Education"),
			@ChoiceListValue(value = "Community-Based"), @ChoiceListValue(value = "Computer Literacy"),
			@ChoiceListValue(value = "Education (Higher Ed.)"), @ChoiceListValue(value = "Education (K-12)"),
			@ChoiceListValue(value = "Elementary Education"),
			@ChoiceListValue(value = "Faculty/teacher professional development"),
			@ChoiceListValue(value = "Federal Work Study"), @ChoiceListValue(value = "Head Start/School Preparedness"),
			@ChoiceListValue(value = "Professional Education"), @ChoiceListValue(value = "Secondary Education"),
			@ChoiceListValue(value = "Service Learning"), @ChoiceListValue(value = "Special Education"),
			@ChoiceListValue(value = "Tutoring & Child Literacy - Elementary"),
			@ChoiceListValue(value = "Tutoring & Child Literacy - High School"),
			@ChoiceListValue(value = "Tutoring & Child Literacy - Middle School") })
	@FindByLabel(label = "Sub-Area of Expertise")
	public WebElement subAreaOfExpertise;
			
}
