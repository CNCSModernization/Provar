package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.provar.core.model.ui.api.UiFacet;
import com.provar.core.testapi.annotations.*;

@Page(title = "Applications", summary = "", relativeUrl = "", connection = "GranteePortal")
public class Applications {

	@TextType()
	@FindBy(xpath = "//th[text()='Primary Focus Area']/following-sibling::td[1]/span")
	public WebElement PrimaryFocusArea;

	@LinkType()
	@FindBy(xpath = "//input[@value='Add Locations']")
	public WebElement AddLocation;

	@TextType()
	@FindBy(xpath = "(//th[text()='Application']/following-sibling::td)[1]//a")
	public WebElement ApplicationID;

	@LinkType()
	@FindBy(xpath = "//input[@value='New Budget Application']")
	public WebElement NewBudgetApplication;

	@LinkType()
	@FindBy(xpath = "//input[@value='Performance Measures']")
	public WebElement PerformanceMeasures;

	@ButtonType()
	@FindBy(xpath = "//input[@value='Submit']")
	public WebElement Submit;

	@PageRow()
	public static class Award {
		@LinkType()
		@FindBy(xpath = ".//th[contains(@class, \"dataCell\")]//a")
		public WebElement AwardId;
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//h3[text()='Award']/ancestor::div[contains(@class,'pbHeader')]/following-sibling::div//table")
	@PageTable(firstRowContainsHeaders = true, row = Award.class)
	public List<Award> Award;

	@ChoiceListType(values = { @ChoiceListValue(value = "Standard"), @ChoiceListValue(value = "Support Grant"),
			@ChoiceListValue(value = "Program Grant") })
	@FindByLabel(label = "Program Type")
	public WebElement programType;

	@ChoiceListType(values = { @ChoiceListValue(value = "Yes"), @ChoiceListValue(value = "No") })
	@FindByLabel(label = "Cost Share")
	public WebElement costShare;

	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save;

	@ButtonType()
	@FindByLabel(label = "Edit")
	public WebElement edit;

	@ChoiceListType(values = { @ChoiceListValue(value = "Available"), @ChoiceListValue(value = "Teacher Corps"), @ChoiceListValue(value = "Post-HS Education Support"), @ChoiceListValue(value = "K-12 Success"), @ChoiceListValue(value = "School Readiness"), @ChoiceListValue(value = "Other") })
	@FindBy(xpath = "//label[contains(text(),'Education')]/../following-sibling::td//select[contains(@id,'deselected')]")
	public WebElement test;

	@ButtonType()
	@FindBy(xpath = "//label[contains(text(),'Education')]/../following-sibling::td//input[1]")
	public WebElement AddRightEdu;

	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save1;

	@ButtonType()
	@FindByLabel(label = "Continue")
	public WebElement continue_;

	@ButtonType()
	@FindByLabel(label = "New Attachment")
	public WebElement newAttachment;

}
