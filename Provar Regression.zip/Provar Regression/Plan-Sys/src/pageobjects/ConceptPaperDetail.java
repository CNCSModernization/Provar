package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.provar.core.model.ui.api.UiFacet;
import com.provar.core.testapi.annotations.*;

@Page( title="Concept Paper Detail"                                
     , summary=""
     , relativeUrl=""
     , connection="GranteePortal"
     )             
public class ConceptPaperDetail {

	@PageWait.Field(timeoutSeconds = 10)
	@LinkType()
	@FindBy(xpath = "//th[text()='Concept Paper ID']/following-sibling::td[1]")
	public WebElement ConceptPaperId;
	
	@ButtonType()
	@FindBy(xpath = "//input[@type='submit']")
	public WebElement Submit;
	
	@TextType()
	@FindBy(xpath = "//th[text()='Application Status']/following-sibling::td[1]")
	public WebElement Status;

	@ButtonType()
	@FindByLabel(label = "Intent to Apply")
	public WebElement IntentToApply;

	@ButtonType()
	@FindByLabel(label = "Apply")
	public WebElement Apply;

	@ButtonType()
	@FindByLabel(label = "Submit")
	public WebElement Submit1;

	@PageRow()
	public static class Applications {

		@LinkType()
		@FindBy(xpath = ".//td[2]/a")
		public WebElement applicationID;
	}

	@FacetFindBys(value = { @FacetFindBy(findBy = @FindBy(xpath = ".//tr"), facet = UiFacet.DATA_ROWS) })
	@FindBy(xpath = "//label[contains(text(),'Application')]/../following-sibling::div//table")
	@PageTable(firstRowContainsHeaders = true, row = Applications.class)
	public List<Applications> Applications;

	@ButtonType()
	@FindByLabel(label = "Search")
	public WebElement search;

	@LinkType()
	@FindBy(linkText = " 015791")
	public WebElement option0;

	@LinkType()
	@FindBy(linkText = "016044")
	public WebElement _016044;
			
}
