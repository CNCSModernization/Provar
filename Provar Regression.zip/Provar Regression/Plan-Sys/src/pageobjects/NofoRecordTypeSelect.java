package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Nofo Record Type Select"                                
               , summary=""
               , page="NofoRecordTypeSelect"
               , namespacePrefix=""
               , object="NOFA__c"
               , connection="POAdmin"
     )             
public class NofoRecordTypeSelect {

	@ChoiceListType(values = { @ChoiceListValue(value = "NOFO"), @ChoiceListValue(value = "RFP") })
	@VisualforceBy(componentXPath = "apex:selectList[@id='chooseColor']")
	public WebElement recordTypeOfNewRecord;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!continueTo}']")
	public WebElement continue_;
	@BooleanType()
	@FindByLabel(label = "Open to Applications")
	public WebElement openToApplications;
	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save;
	@ChoiceListType(values = { @ChoiceListValue(value = "NCCC Traditional"),
			@ChoiceListValue(value = "NCCC Traditional"), @ChoiceListValue(value = "NCCC E2E Test Program"),
			@ChoiceListValue(value = "Stephen's NCCC Program") })
	@FindBy(id = "CF00Nr0000000IK8N_lkid")
	public WebElement ProgName;
	@TextType()
	@FindByLabel(label = "Application Input Deadline")
	public WebElement applicationInputDeadline;
	@TextType()
	@FindByLabel(label = "Application Deadline")
	public WebElement applicationDeadline;
	
}
