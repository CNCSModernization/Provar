package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@Page( title="ExpertReviewer"                                
     , summary=""
     , relativeUrl=""
     , connection="ExpertReviewer_UI"
     )             
public class ExpertReviewer {

	@LinkType()
	@FindBy(linkText = "Create a new account")
	public WebElement createANewAccount;
	@ChoiceListType(values = { @ChoiceListValue(value = "Mr."), @ChoiceListValue(value = "Ms."),
			@ChoiceListValue(value = "Mrs."), @ChoiceListValue(value = "Dr.") })
	@FindByLabel(label = "Prefix")
	public WebElement prefix;
	@TextType()
	@FindByLabel(label = "First Name")
	public WebElement firstName;
	@TextType()
	@FindByLabel(label = "Last Name")
	public WebElement lastName;
	@TextType()
	@FindByLabel(label = "Primary Phone")
	public WebElement primaryPhone;
	@ChoiceListType(values = { @ChoiceListValue(value = "Yes"), @ChoiceListValue(value = "No") })
	@FindByLabel(label = "Is this a Mobile Number")
	public WebElement isThisAMobileNumber;
	@ChoiceListType(values = { @ChoiceListValue(value = "Yes"), @ChoiceListValue(value = "No") })
	@FindByLabel(label = "Would you like to receive texts?")
	public WebElement wouldYouLikeToReceiveTexts;
	@TextType()
	@FindByLabel(label = "Email (Username)")
	public WebElement emailUsername;
	@TextType()
	@FindByLabel(label = "Re-Enter Email (Username)")
	public WebElement reEnterEmailUsername;
	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save;
	@LinkType()
	@FindBy(xpath = "//li[@class=\"wt-Reviewer-Application\"]/a")
	public WebElement reviewerApplication;
	@TextType()
	@FindByLabel(label = "From")
	public WebElement from;
	@LinkType()
	@FindBy(linkText = "NOFOs/RFPs")
	public WebElement nOFOsRFPs;
	@TextType()
	@FindBy(id = "phSearchInput")
	public WebElement search;
	@LinkType()
	@FindBy(linkText = " 015791")
	public WebElement option0;
	@LinkType()
	@FindBy(linkText = "015791")
	public WebElement _015791;
	@ButtonType()
	@FindByLabel(label = "Apply")
	public WebElement apply;
	@ChoiceListType(values = { @ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "CA"), @ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"),
			@ChoiceListValue(value = "DC"), @ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"),
			@ChoiceListValue(value = "GA"), @ChoiceListValue(value = "GU"), @ChoiceListValue(value = "HI"),
			@ChoiceListValue(value = "IA"), @ChoiceListValue(value = "ID"), @ChoiceListValue(value = "IL"),
			@ChoiceListValue(value = "IN"), @ChoiceListValue(value = "JM"), @ChoiceListValue(value = "KS"),
			@ChoiceListValue(value = "KY"), @ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"),
			@ChoiceListValue(value = "MD"), @ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MI"),
			@ChoiceListValue(value = "MN"), @ChoiceListValue(value = "MO"), @ChoiceListValue(value = "MS"),
			@ChoiceListValue(value = "MT"), @ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"),
			@ChoiceListValue(value = "NE"), @ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"),
			@ChoiceListValue(value = "NM"), @ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"),
			@ChoiceListValue(value = "OH"), @ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"),
			@ChoiceListValue(value = "PA"), @ChoiceListValue(value = "PR"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "TN"),
			@ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UT"), @ChoiceListValue(value = "VA"),
			@ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"), @ChoiceListValue(value = "WA"),
			@ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"), @ChoiceListValue(value = "WY") })
	@FindByLabel(label = "Project State")
	public WebElement projectState;
	@TextType(maxLength = 6, minLength = 6)
	@FindByLabel(label = "Project Title")
	public WebElement projectTitle;
	@TextType()
	@FindByLabel(label = "Street Address 1")
	public WebElement streetAddress1;
	@TextType()
	@FindByLabel(label = "City")
	public WebElement city;
	@ChoiceListType(values = { @ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "CA"), @ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"),
			@ChoiceListValue(value = "DC"), @ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"),
			@ChoiceListValue(value = "GA"), @ChoiceListValue(value = "GU"), @ChoiceListValue(value = "HI"),
			@ChoiceListValue(value = "IA"), @ChoiceListValue(value = "ID"), @ChoiceListValue(value = "IL"),
			@ChoiceListValue(value = "IN"), @ChoiceListValue(value = "KS"), @ChoiceListValue(value = "KY"),
			@ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"), @ChoiceListValue(value = "MD"),
			@ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MI"), @ChoiceListValue(value = "MN"),
			@ChoiceListValue(value = "MO"), @ChoiceListValue(value = "MP"), @ChoiceListValue(value = "MS"),
			@ChoiceListValue(value = "MT"), @ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"),
			@ChoiceListValue(value = "NE"), @ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"),
			@ChoiceListValue(value = "NM"), @ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"),
			@ChoiceListValue(value = "OH"), @ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"),
			@ChoiceListValue(value = "PA"), @ChoiceListValue(value = "PR"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "TN"),
			@ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UT"), @ChoiceListValue(value = "VA"),
			@ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"), @ChoiceListValue(value = "WA"),
			@ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"), @ChoiceListValue(value = "WY") })
	@FindByLabel(label = "State")
	public WebElement state;
	@TextType()
	@FindByLabel(label = "Zip")
	public WebElement zip;
	@TextType()
	@FindByLabel(label = "Project Director")
	public WebElement projectDirector;
	@TextType()
	@FindByLabel(label = "Project Title")
	public WebElement projectTitle1;
	@BooleanType()
	@FindByLabel(label = "1001 SOUTH MAIN STREET,CORONA CA 92882-4410,UNITED STATES")
	public WebElement _1001SOUTHMAINSTREETCORONACA928824410UNITEDSTATES;
	@ButtonType()
	@FindByLabel(label = "Use Suggested Address")
	public WebElement useSuggestedAddress;
	@TextType()
	@FindByLabel(label = "Point of Contact")
	public WebElement pointOfContact;
	@TextType()
	@FindByLabel(label = "Proposed Start Date")
	public WebElement proposedStartDate;
	@TextType()
	@FindByLabel(label = "Proposed End Date")
	public WebElement proposedEndDate;
	@ChoiceListType(values = { @ChoiceListValue(value = "0", title = "AL"), @ChoiceListValue(value = "1", title = "AK"),
			@ChoiceListValue(value = "2", title = "AR"), @ChoiceListValue(value = "3", title = "AS"),
			@ChoiceListValue(value = "4", title = "AZ"), @ChoiceListValue(value = "5", title = "CA"),
			@ChoiceListValue(value = "6", title = "CO"), @ChoiceListValue(value = "7", title = "CT"),
			@ChoiceListValue(value = "8", title = "DC"), @ChoiceListValue(value = "9", title = "DE"),
			@ChoiceListValue(value = "10", title = "FL"), @ChoiceListValue(value = "11", title = "GA"),
			@ChoiceListValue(value = "12", title = "HI"), @ChoiceListValue(value = "13", title = "ID"),
			@ChoiceListValue(value = "14", title = "IL"), @ChoiceListValue(value = "15", title = "IN"),
			@ChoiceListValue(value = "16", title = "IA"), @ChoiceListValue(value = "17", title = "KS"),
			@ChoiceListValue(value = "18", title = "KY"), @ChoiceListValue(value = "19", title = "LA"),
			@ChoiceListValue(value = "20", title = "ME"), @ChoiceListValue(value = "21", title = "MD"),
			@ChoiceListValue(value = "22", title = "MA"), @ChoiceListValue(value = "23", title = "MI"),
			@ChoiceListValue(value = "24", title = "MN"), @ChoiceListValue(value = "25", title = "MS"),
			@ChoiceListValue(value = "26", title = "MO"), @ChoiceListValue(value = "27", title = "MT"),
			@ChoiceListValue(value = "28", title = "NE"), @ChoiceListValue(value = "29", title = "NV"),
			@ChoiceListValue(value = "30", title = "NH"), @ChoiceListValue(value = "31", title = "NJ"),
			@ChoiceListValue(value = "32", title = "NM"), @ChoiceListValue(value = "33", title = "NY"),
			@ChoiceListValue(value = "34", title = "NC"), @ChoiceListValue(value = "35", title = "ND"),
			@ChoiceListValue(value = "36", title = "OH"), @ChoiceListValue(value = "37", title = "OK"),
			@ChoiceListValue(value = "38", title = "OR"), @ChoiceListValue(value = "39", title = "PA"),
			@ChoiceListValue(value = "40", title = "RI"), @ChoiceListValue(value = "41", title = "SC"),
			@ChoiceListValue(value = "42", title = "SD"), @ChoiceListValue(value = "43", title = "TN"),
			@ChoiceListValue(value = "44", title = "TX"), @ChoiceListValue(value = "45", title = "UT"),
			@ChoiceListValue(value = "46", title = "VT"), @ChoiceListValue(value = "47", title = "VA"),
			@ChoiceListValue(value = "48", title = "WA"), @ChoiceListValue(value = "49", title = "WV"),
			@ChoiceListValue(value = "50", title = "WI"), @ChoiceListValue(value = "51", title = "WY"),
			@ChoiceListValue(value = "52", title = "GU"), @ChoiceListValue(value = "53", title = "MP"),
			@ChoiceListValue(value = "54", title = "PR"), @ChoiceListValue(value = "55", title = "VI") })
	@FindBy(xpath = "//*[@id=\"j_id0:theForm:j_id2:j_id48:j_id49_unselected\"]/optgroup/option[6]")
	public WebElement stateAndOrTerritories;
	@LinkType()
	@FindBy(xpath = "//td[2]/div[2]//a[1]")
	public WebElement Select;
	@TextType()
	@FindByLabel(label = "Counties")
	public WebElement counties;
	@TextType()
	@FindByLabel(label = "Cities")
	public WebElement cities;
	@ChoiceListType(values = { @ChoiceListValue(value = "Standard"), @ChoiceListValue(value = "Support Grant"),
			@ChoiceListValue(value = "Program Grant") })
	@FindByLabel(label = "Program Type")
	public WebElement programType;
	@ChoiceListType(values = { @ChoiceListValue(value = "Yes"), @ChoiceListValue(value = "No") })
	@FindByLabel(label = "Cost Share")
	public WebElement costShare;
	@ChoiceListType(values = { @ChoiceListValue(value = "Chosen") })
	@FindBy(name = "j_id0:theForm:j_id2:j_id124:j_id203:j_id205:j_id206:selected")
	public WebElement selected;
	@TextType()
	@FindBy(xpath = "//*[@id=\"cke_j_id0:theForm:j_id2:j_id297:j_id303:j_id307:textAreaDelegate_Executive_Summary__c\"]")
	public WebElement textAreaDelegate_Executive_Summary__c;
	@TextType()
	@FindBy(xpath = "//*[@id=\"cke_j_id0:theForm:j_id2:j_id297:j_id313:j_id317:textAreaDelegate_Need__c\"]")
	public WebElement textAreaDelegate_Need__c;
	@TextType()
	@FindBy(xpath = "//*[@id=\"cke_j_id0:theForm:j_id2:j_id297:j_id318:j_id322:textAreaDelegate_Strengthen_Communities__c\"]")
	public WebElement textAreaDelegate_Strengthen_Communities__c;
	@TextType()
	@FindBy(xpath = "//*[@id=\"cke_j_id0:theForm:j_id2:j_id297:j_id333:j_id337:textAreaDelegate_Organizational_Capability__c\"]")
	public WebElement textAreaDelegate_Organizational_Capability__c;
	@TextType()
	@FindBy(xpath = "//*[@id=\"cke_j_id0:theForm:j_id2:j_id297:j_id358:j_id362:textAreaDelegate_Intermediary_Justification__c\"]")
	public WebElement textAreaDelegate_Intermediary_Justification__c;
	@ChoiceListType(values = { @ChoiceListValue(value = "Operating Site"), @ChoiceListValue(value = "Service Location"),
			@ChoiceListValue(value = "Member Lodging"), @ChoiceListValue(value = "Inclement Weather Site") })
	@FindByLabel(label = "Location Type")
	public WebElement locationType;
	@TextType()
	@FindByLabel(label = "Location Name")
	public WebElement locationName;
	@TextType()
	@FindByLabel(label = "Supervisor Name")
	public WebElement supervisorName;
	@TextType()
	@FindByLabel(label = "Supervisor Email")
	public WebElement supervisorEmail;
	@TextType()
	@FindByLabel(label = "Supervisor Phone Number")
	public WebElement supervisorPhoneNumber;
	@TextType()
	@FindByLabel(label = "Street Address 1")
	public WebElement streetAddress11;
	@ChoiceListType(values = { @ChoiceListValue(value = "AA"), @ChoiceListValue(value = "AE"),
			@ChoiceListValue(value = "AK"), @ChoiceListValue(value = "AL"), @ChoiceListValue(value = "AP"),
			@ChoiceListValue(value = "AR"), @ChoiceListValue(value = "AS"), @ChoiceListValue(value = "AZ"),
			@ChoiceListValue(value = "BA"), @ChoiceListValue(value = "BM"), @ChoiceListValue(value = "CA"),
			@ChoiceListValue(value = "CO"), @ChoiceListValue(value = "CT"), @ChoiceListValue(value = "DC"),
			@ChoiceListValue(value = "DE"), @ChoiceListValue(value = "FL"), @ChoiceListValue(value = "GA"),
			@ChoiceListValue(value = "GU"), @ChoiceListValue(value = "HI"), @ChoiceListValue(value = "IA"),
			@ChoiceListValue(value = "ID"), @ChoiceListValue(value = "IL"), @ChoiceListValue(value = "IN"),
			@ChoiceListValue(value = "JM"), @ChoiceListValue(value = "KS"), @ChoiceListValue(value = "KY"),
			@ChoiceListValue(value = "LA"), @ChoiceListValue(value = "MA"), @ChoiceListValue(value = "MD"),
			@ChoiceListValue(value = "ME"), @ChoiceListValue(value = "MI"), @ChoiceListValue(value = "MN"),
			@ChoiceListValue(value = "MO"), @ChoiceListValue(value = "MS"), @ChoiceListValue(value = "MT"),
			@ChoiceListValue(value = "NC"), @ChoiceListValue(value = "ND"), @ChoiceListValue(value = "NE"),
			@ChoiceListValue(value = "NH"), @ChoiceListValue(value = "NJ"), @ChoiceListValue(value = "NM"),
			@ChoiceListValue(value = "NV"), @ChoiceListValue(value = "NY"), @ChoiceListValue(value = "OH"),
			@ChoiceListValue(value = "OK"), @ChoiceListValue(value = "OR"), @ChoiceListValue(value = "PA"),
			@ChoiceListValue(value = "PR"), @ChoiceListValue(value = "PW"), @ChoiceListValue(value = "RI"),
			@ChoiceListValue(value = "SC"), @ChoiceListValue(value = "SD"), @ChoiceListValue(value = "SP"),
			@ChoiceListValue(value = "TN"), @ChoiceListValue(value = "TX"), @ChoiceListValue(value = "UT"),
			@ChoiceListValue(value = "VA"), @ChoiceListValue(value = "VI"), @ChoiceListValue(value = "VT"),
			@ChoiceListValue(value = "WA"), @ChoiceListValue(value = "WI"), @ChoiceListValue(value = "WV"),
			@ChoiceListValue(value = "WY"), @ChoiceListValue(value = "XX") })
	@FindByLabel(label = "State")
	public WebElement state1;
	@TextType()
	@FindByLabel(label = "Location EIN")
	public WebElement locationEIN;
	@BooleanType()
	@FindByLabel(label = "1010 MAIN STREET,ARLINGTON VA 22090,UNITED STATES")
	public WebElement _1010MAINSTREETARLINGTONVA22090UNITEDSTATES;
	@ButtonType()
	@FindByLabel(label = "Use New Address")
	public WebElement useNewAddress;
	@BooleanType()
	@FindByLabel(label = "3717 COLUMBIA PIKE,ARLINGTON VA 22204-4255,UNITED STATES")
	public WebElement _3717COLUMBIAPIKEARLINGTONVA222044255UNITEDSTATES;
	@LinkType()
	@FindBy(linkText = "Applications")
	public WebElement applications;
	@ButtonType()
	@FindByLabel(label = "New Budget Application")
	public WebElement newBudgetApplication;
	@ChoiceListType(values = { @ChoiceListValue(value = "ACSN - Cost Reimbursement") })
	@FindBy(name = "j_id0:j_id152:new_budget_block:j_id182:j_id186:template_select")
	public WebElement template_select;
	@ButtonType()
	@FindByLabel(label = "Create new Budget Application")
	public WebElement createNewBudgetApplication;
	@TextType()
	@FindBy(xpath = "//*[@id=\"img_j_id0:j_id199:view:j_id251:0:j_id253\"]")
	public WebElement CollapseInBudget;
	@TextType()
	@FindBy(xpath = "//*[@id=\"img_j_id0:j_id199:view:j_id251:0:j_id253:j_id255:1:j_id257\"]")
	public WebElement CollapseInBudget2;
	@TextType()
	@FindBy(xpath = "//*[@id=\"img_j_id0:j_id199:view:j_id251:0:j_id253:j_id255:1:j_id257:j_id259:0:j_id260:j_id261:indirect_line\"]")
	public WebElement indirect_line;
	@ChoiceListType(values = { @ChoiceListValue(value = "ACSN 2-Year Half Time Members (Year 1) with Living Allowance"),
			@ChoiceListValue(value = "ACSN 2-Year Half Time Members (Year 1) without Living Allowance"),
			@ChoiceListValue(value = "ACSN 2-Year Half Time Members (Year 2) with Living Allowance"),
			@ChoiceListValue(value = "ACSN 2-Year Half Time Members (Year 2) without Living Allowance"),
			@ChoiceListValue(value = "ACSN Full-Time Members with Living Allowance"),
			@ChoiceListValue(value = "ACSN Full-Time Members without Living Allowance"),
			@ChoiceListValue(value = "ACSN Half-Time Members with Living Allowance"),
			@ChoiceListValue(value = "ACSN Half-Time Members without Living Allowance"),
			@ChoiceListValue(value = "ACSN Minimum-Time Members with Living Allowance"),
			@ChoiceListValue(value = "ACSN Minimum-Time Members without Living Allowance"),
			@ChoiceListValue(value = "ACSN Quarter-Time Members with Living Allowance"),
			@ChoiceListValue(value = "ACSN Quarter-Time Members without Living Allowance"),
			@ChoiceListValue(value = "ACSN Reduced Half-Time Members with Living Allowance"),
			@ChoiceListValue(value = "ACSN Reduced Half-Time Members without Living Allowance") })
	@FindBy(name = "j_id0:j_id199:view:j_id251:0:j_id253:j_id255:1:j_id257:j_id259:0:j_id260:j_id261:indirect_line:j_id265:j_id283")
	public WebElement ACSN2_Year;
	@TextType()
	@FindBy(name = "j_id0:j_id199:view:j_id251:0:j_id253:j_id255:1:j_id257:j_id259:0:j_id260:j_id261:indirect_line:j_id265:0:j_id330")
	public WebElement Add1;
	@TextType()
	@FindBy(name = "j_id0:j_id199:view:j_id251:0:j_id253:j_id255:1:j_id257:j_id259:0:j_id260:j_id261:indirect_line:j_id265:0:j_id338")
	public WebElement _ndRow;
	@TextType()
	@FindBy(name = "j_id0:j_id199:view:j_id251:0:j_id253:j_id255:1:j_id257:j_id259:0:j_id260:j_id261:indirect_line:j_id265:0:j_id426")
	public WebElement cNCSShare;
	@TextType()
	@FindBy(name = "j_id0:j_id199:view:j_id251:0:j_id253:j_id255:1:j_id257:j_id259:0:j_id260:j_id261:indirect_line:j_id265:0:j_id431")
	public WebElement granteeShare;
	@ButtonType()
	@FindByLabel(label = "Final Save")
	public WebElement finalSave;
	@LinkType()
	@FindBy(linkText = "18VS336678")
	public WebElement _18VS336678;
	@LinkType()
	@FindBy(xpath = "//td[2]/div[2]//a[1]")
	public WebElement AddState;
	@ChoiceListType(values = { @ChoiceListValue(value = "0", title = "AL"), @ChoiceListValue(value = "1", title = "AK"),
			@ChoiceListValue(value = "2", title = "AR"), @ChoiceListValue(value = "3", title = "AS"),
			@ChoiceListValue(value = "4", title = "AZ"), @ChoiceListValue(value = "5", title = "CA"),
			@ChoiceListValue(value = "6", title = "CO"), @ChoiceListValue(value = "7", title = "CT"),
			@ChoiceListValue(value = "8", title = "DC"), @ChoiceListValue(value = "9", title = "DE"),
			@ChoiceListValue(value = "10", title = "FL"), @ChoiceListValue(value = "11", title = "GA"),
			@ChoiceListValue(value = "12", title = "HI"), @ChoiceListValue(value = "13", title = "ID"),
			@ChoiceListValue(value = "14", title = "IL"), @ChoiceListValue(value = "15", title = "IN"),
			@ChoiceListValue(value = "16", title = "IA"), @ChoiceListValue(value = "17", title = "KS"),
			@ChoiceListValue(value = "18", title = "KY"), @ChoiceListValue(value = "19", title = "LA"),
			@ChoiceListValue(value = "20", title = "ME"), @ChoiceListValue(value = "21", title = "MD"),
			@ChoiceListValue(value = "22", title = "MA"), @ChoiceListValue(value = "23", title = "MI"),
			@ChoiceListValue(value = "24", title = "MN"), @ChoiceListValue(value = "25", title = "MS"),
			@ChoiceListValue(value = "26", title = "MO"), @ChoiceListValue(value = "27", title = "MT"),
			@ChoiceListValue(value = "28", title = "NE"), @ChoiceListValue(value = "29", title = "NV"),
			@ChoiceListValue(value = "30", title = "NH"), @ChoiceListValue(value = "31", title = "NJ"),
			@ChoiceListValue(value = "32", title = "NM"), @ChoiceListValue(value = "33", title = "NY"),
			@ChoiceListValue(value = "34", title = "NC"), @ChoiceListValue(value = "35", title = "ND"),
			@ChoiceListValue(value = "36", title = "OH"), @ChoiceListValue(value = "37", title = "OK"),
			@ChoiceListValue(value = "38", title = "OR"), @ChoiceListValue(value = "39", title = "PA"),
			@ChoiceListValue(value = "40", title = "RI"), @ChoiceListValue(value = "41", title = "SC"),
			@ChoiceListValue(value = "42", title = "SD"), @ChoiceListValue(value = "43", title = "TN"),
			@ChoiceListValue(value = "44", title = "TX"), @ChoiceListValue(value = "45", title = "UT"),
			@ChoiceListValue(value = "46", title = "VT"), @ChoiceListValue(value = "47", title = "VA"),
			@ChoiceListValue(value = "48", title = "WA"), @ChoiceListValue(value = "49", title = "WV"),
			@ChoiceListValue(value = "50", title = "WI"), @ChoiceListValue(value = "51", title = "WY"),
			@ChoiceListValue(value = "52", title = "GU"), @ChoiceListValue(value = "53", title = "MP"),
			@ChoiceListValue(value = "54", title = "PR"), @ChoiceListValue(value = "55", title = "VI") })
	@FindBy(xpath = "//*[@id=\"j_id0:theForm:j_id2:j_id48:j_id49_unselected\"]//option[48]")
	public WebElement stateAndOrTerritories1;
	@ChoiceListType(values = { @ChoiceListValue(value = "47", title = "VA") })
	@FindBy(xpath = "//*[@id=\"j_id0:theForm:j_id2:j_id48:j_id49_selected\"]//option")
	public WebElement stateAndOrTerritories2;
	@ChoiceListType(values = { @ChoiceListValue(value = "0", title = "AL"), @ChoiceListValue(value = "1", title = "AK"), @ChoiceListValue(value = "2", title = "AR"), @ChoiceListValue(value = "3", title = "AS"), @ChoiceListValue(value = "4", title = "AZ"), @ChoiceListValue(value = "5", title = "CA"), @ChoiceListValue(value = "6", title = "CO"), @ChoiceListValue(value = "7", title = "CT"), @ChoiceListValue(value = "8", title = "DC"), @ChoiceListValue(value = "9", title = "DE"), @ChoiceListValue(value = "10", title = "FL"), @ChoiceListValue(value = "11", title = "GA"), @ChoiceListValue(value = "12", title = "HI"), @ChoiceListValue(value = "13", title = "ID"), @ChoiceListValue(value = "14", title = "IL"), @ChoiceListValue(value = "15", title = "IN"), @ChoiceListValue(value = "16", title = "IA"), @ChoiceListValue(value = "17", title = "KS"), @ChoiceListValue(value = "18", title = "KY"), @ChoiceListValue(value = "19", title = "LA"), @ChoiceListValue(value = "20", title = "ME"), @ChoiceListValue(value = "21", title = "MD"), @ChoiceListValue(value = "22", title = "MA"), @ChoiceListValue(value = "23", title = "MI"), @ChoiceListValue(value = "24", title = "MN"), @ChoiceListValue(value = "25", title = "MS"), @ChoiceListValue(value = "26", title = "MO"), @ChoiceListValue(value = "27", title = "MT"), @ChoiceListValue(value = "28", title = "NE"), @ChoiceListValue(value = "29", title = "NV"), @ChoiceListValue(value = "30", title = "NH"), @ChoiceListValue(value = "31", title = "NJ"), @ChoiceListValue(value = "32", title = "NM"), @ChoiceListValue(value = "33", title = "NY"), @ChoiceListValue(value = "34", title = "NC"), @ChoiceListValue(value = "35", title = "ND"), @ChoiceListValue(value = "36", title = "OH"), @ChoiceListValue(value = "37", title = "OK"), @ChoiceListValue(value = "38", title = "OR"), @ChoiceListValue(value = "39", title = "PA"), @ChoiceListValue(value = "40", title = "RI"), @ChoiceListValue(value = "41", title = "SC"), @ChoiceListValue(value = "42", title = "SD"), @ChoiceListValue(value = "43", title = "TN"), @ChoiceListValue(value = "44", title = "TX"), @ChoiceListValue(value = "45", title = "UT"), @ChoiceListValue(value = "46", title = "VT"), @ChoiceListValue(value = "47", title = "VA"), @ChoiceListValue(value = "48", title = "WA"), @ChoiceListValue(value = "49", title = "WV"), @ChoiceListValue(value = "50", title = "WI"), @ChoiceListValue(value = "51", title = "WY"), @ChoiceListValue(value = "52", title = "GU"), @ChoiceListValue(value = "53", title = "MP"), @ChoiceListValue(value = "54", title = "PR"), @ChoiceListValue(value = "55", title = "VI") })
	@FindBy(xpath = "//select[contains(@id,'unselected')and contains(@title,'State')]")
	public WebElement stateAndOrTerritories3;
	@LinkType()
	@FindBy(xpath = "//td[2]/div[2]//a[1]")
	public WebElement btnright2;
	@LinkType()
	@FindBy(xpath = "(//td[@class='multiSelectPicklistCell']/a[@title='Add'])[1]")
	public WebElement rightbtn;
	@TextType()
	@FindBy(xpath = "//label[contains(text(),'State')]/../following-sibling::td//a[1]")
	public WebElement btnRightState;
	@ChoiceListType(values = { @ChoiceListValue(value = "Available"), @ChoiceListValue(value = "K-12 Success"), @ChoiceListValue(value = "Post-HS Education Support"), @ChoiceListValue(value = "School Readiness"), @ChoiceListValue(value = "Teacher Corps"), @ChoiceListValue(value = "Other") })
	@FindBy(xpath = "//label[contains(text(),'Education')]/../following-sibling::td//select[contains(@id,'deselected')]")
	public WebElement Education;
	@ButtonType()
	@FindBy(xpath = "//label[contains(text(),'Education')]/../following-sibling::td//input[1]")
	public WebElement btnRightEducation;
	@LinkType()
	@FindBy(linkText = "NOFOs/RFPs")
	public WebElement nOFOsRFPs1;
	@LinkType()
	@FindBy(linkText = "NOFOs/RFPs")
	public WebElement nOFOsRFPs2;
	@LinkType()
	@FindBy(linkText = "NOFOs/RFPs")
	public WebElement nOFOsRFPs3;
	@ButtonType()
	@FindByLabel(label = "Save")
	public WebElement save1;
	@ButtonType()
	@FindBy(xpath = "//*[@id=\"bottomButtonRow\"]//input[1]")
	public WebElement save2;
	@TextType()
	@FindByLabel(label = "NOFO/RFP ID")
	public WebElement nOFORFPID;
	@ButtonType()
	@FindByLabel(label = "Continue")
	public WebElement continue_;
	@VisualforceBy(componentXPath = "//*[@id=j_id0:theForm:pgbtnid:j_id346:j_id357:j_id361:textAreaDelegate_Continuation_Changes__c_rta_body")
	@TextType()
	public WebElement textAreaDelegate_Continuation_Changes__c;
	@LinkType()
	@FindBy(xpath = "//*[@id=\"pg:j_id485_body\"]/table/tbody/tr[2]/td[1]/a[1]")
	public WebElement edit;
	@ButtonType()
	@FindByLabel(label = "Search")
	public WebElement search1;
	@LinkType()
	@FindBy(linkText = "015878")
	public WebElement Select1;
			
}
