package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title="Stage Panelling"                                
               , summary=""
               , page="StagePanelling"
               , namespacePrefix=""
               , object="Stages__c"
               , connection="OGPO"
     )             
public class StagePanelling {

	@PageWaitAfter.Timed(durationSeconds = 6)
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!DoAdd}']")
	public WebElement addPanel;
	@PageTable(row = ObjectList.class)
	@VisualforceBy(componentXPath = "apex:pageBlockTable[@id='pbTable']")
	public List<ObjectList> objectList;

	@PageRow(byColumn = true)
	public static class ObjectList {

		@TextType()
		@FindBy(xpath = ".//td[3]//span[@class=\"dateInput dateOnlyInput\"]/input")
		public WebElement StartDate;
		@TextType()
		@FindBy(xpath = ".//td[4]//span[@class=\"dateInput dateOnlyInput\"]/input")
		public WebElement EndDate;
		@ChoiceListType(values = { @ChoiceListValue(value = "Staff"), @ChoiceListValue(value = "Expert or Blended") })
		@FindBy(xpath = ".//td[contains(@class, \"dataCol\")]//select")
		public WebElement noneStaffExpertOrBlended;
		@LinkType()
		@FindBy(xpath = ".//td[2]/span/a")
		public WebElement panelID;
	}

	@PageWaitAfter.Timed(durationSeconds = 6)
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandButton[@action='{!DoSave}']")
	public WebElement save;
	
}
