package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.provar.core.testapi.annotations.*;

@SalesforcePage( title=""                                
               , summary=""
               , page="projectlook"
               , namespacePrefix=""
               , object="NOFA__c"
               , connection="GranteePortal"
     )             
public class projectlook {

	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandbutton[@action='{!createProject}']")
	public WebElement create;
	@TextType()
	@VisualforceBy(componentXPath = "apex:inputField[@id='theLookup']")
	public WebElement selectAProject;
	@ButtonType()
	@VisualforceBy(componentXPath = "apex:commandbutton[@action='{!Apply}']")
	public WebElement apply;
	
}
